// next/documents/manifest.json
var manifest_default = {
  version: 1,
  synthetic: true,
  files: {
    "case-10-v1.pdf": {
      bytes: 84309,
      sha256: "77ccbda18bf0ecf21c4708450b9fb1c0f0a943eee379bb96440c790a7b93b8ec"
    },
    "case-3-v1.pdf": {
      bytes: 85153,
      sha256: "0b0eef4e0c1f11525cf1ca3a98efb1a8ba51f1fae17ee5a6f8862eb79d443595"
    },
    "case-4-v1.pdf": {
      bytes: 83254,
      sha256: "7562e0f0bb12e8a4412c932fa25a81bb21dd4455111350ec3afad264002217c6"
    },
    "case-4-v2.pdf": {
      bytes: 82997,
      sha256: "23427c8d9b9be03b97e818157921ffa78bda45f783f353f45f0fc953ab005b0b"
    },
    "case-5-v1.pdf": {
      bytes: 82012,
      sha256: "e3876934d446a2b2d8c1cc707d7ab48cb325eade20dadff4a641a546104bc057"
    },
    "case-6-v1.pdf": {
      bytes: 84928,
      sha256: "b941d832acb338d33636ad0618b3d8495989725f5e5d8d53078d9244968911a2"
    },
    "case-7-v1.pdf": {
      bytes: 84424,
      sha256: "2dc320c3ad3622d0b22d0d226fbf02d6ab07a8c0b6416e45e24737498f41eaeb"
    },
    "case-8-v1.pdf": {
      bytes: 85745,
      sha256: "8f78727c6e15861167dc53b54fe3c34606dbd59a4473c876de15d4fd60385f9b"
    },
    "case-9-v1.pdf": {
      bytes: 85056,
      sha256: "62c03413b1e28021a910869cab256ec4c2d210db1c956f6d637d2f8f1d23ace6"
    },
    "51-lab.pdf": {
      bytes: 146796,
      sha256: "7e2dee05b6ebbe5b0ac152631c4612a6a8b0b649eccebc7f3aa8b61db787bcdc"
    }
  }
};

// next/care.ts
function need(ok, message) {
  if (!ok) throw Error(message);
}
var clean = (s) => String(s || "").trim().slice(0, 4e3);
var id = () => crypto.randomUUID();
var localDay = (value = /* @__PURE__ */ new Date()) => value.toLocaleDateString("en-CA", { timeZone: "Asia/Tehran" });
var doctorPhones = ["09000000011", "09000000014"];
function care(c) {
  const j = c.care ??= { history: { medicines: "", allergies: "", other: "" }, encounters: [], referrals: [], reviews: [], reports: [], responsibilities: [], handovers: [], barriers: [], decisions: {}, membership: { state: "trial", receipts: [], continuityNote: "" }, notifications: [] };
  for (const f of c.files) if (!f.review && !j.reports.some((m) => m.fileId === f.id) && !j.reviews.some((r) => r.fileId === f.id && r.signedAt) && !j.responsibilities.some((r) => r.subject === "report:" + f.id)) j.responsibilities.push({ id: "legacy-report-" + c.phone + "-" + f.id, subject: "report:" + f.id, title: "\u0628\u0631\u0631\u0633\u06CC \u0645\u062F\u0631\u06A9 \u0645\u0648\u062C\u0648\u062F", owner: j.handovers.findLast((h) => h.state === "accepted")?.to || c.doctor, dueAt: localDay(), next: "\u0627\u0635\u0644 \u0645\u062F\u0631\u06A9 \u0645\u0648\u062C\u0648\u062F \u0631\u0627 \u0645\u0631\u0648\u0631 \u0648 \u062A\u0648\u0636\u06CC\u062D \u0642\u0627\u0628\u0644 \u0641\u0647\u0645 \u0645\u0646\u062A\u0634\u0631 \u06A9\u0646\u06CC\u062F.", state: "open", escalated: false });
  for (const p of c.plans) for (const a of p.actions) if (!a.done && !a.dueAt && !j.responsibilities.some((r) => r.subject === "action:" + a.id)) j.responsibilities.push({ id: "legacy-action-" + c.phone + "-" + a.id, subject: "action:" + a.id, title: a.title, owner: j.handovers.findLast((h) => h.state === "accepted")?.to || c.doctor, dueAt: localDay(), next: a.why, state: "open", escalated: false });
  return j;
}
function membershipState(c, now = Date.now()) {
  const m = care(c).membership;
  return m.state === "active" && m.endsAt && m.endsAt <= now ? "expired" : m.state;
}
function effectiveDoctor(c) {
  return c.care?.handovers.findLast((h) => h.state === "accepted")?.to || c.doctor;
}
function clinicalAccess(a, c) {
  return (a.organizationId || "salamatban-demo") === (c.organizationId || "salamatban-demo") && a.role === "clinician" && (a.phone === effectiveDoctor(c) || a.phone === c.doctor) && (c.phase !== "draft" || c.urgent);
}
function coordinationAccess(a, c) {
  return (a.organizationId || "salamatban-demo") === (c.organizationId || "salamatban-demo") && a.role === "coordinator" && (c.tasks.some((t) => t.owner === a.phone) || c.care?.referrals.some((r) => r.coordinator === a.phone) || c.care?.barriers.some((b) => b.owner === a.phone));
}
function due(s) {
  need(/^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s)), "\u062A\u0627\u0631\u06CC\u062E \u0645\u0639\u062A\u0628\u0631 \u0628\u0631\u0627\u06CC \u0645\u0648\u0639\u062F \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
  return s;
}
function addResponsibility(c, subject, title, dueAt, next) {
  const j = care(c);
  if (j.responsibilities.some((r) => r.subject === subject && r.state === "open")) return;
  j.responsibilities.push({ id: id(), subject, title, owner: effectiveDoctor(c), dueAt, next, state: "open", escalated: false });
}
function notify(c, subject) {
  care(c).notifications.push({ id: id(), owner: "09000000013", subject, state: "pending", attempts: 0, at: Date.now() });
}
function careTransition(original, a, cmd, expected) {
  need(original.version === expected, "\u067E\u0631\u0648\u0646\u062F\u0647 \u062F\u0631 \u067E\u0646\u062C\u0631\u0647\u0654 \u062F\u06CC\u06AF\u0631\u06CC \u062A\u063A\u06CC\u06CC\u0631 \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A\u061B \u062A\u0627\u0632\u0647\u200C\u0633\u0627\u0632\u06CC \u06A9\u0646\u06CC\u062F.");
  need((original.organizationId || "salamatban-demo") === (a.organizationId || "salamatban-demo"), "\u0628\u0647 \u0627\u06CC\u0646 \u0633\u0627\u0632\u0645\u0627\u0646 \u062F\u0633\u062A\u0631\u0633\u06CC \u0646\u062F\u0627\u0631\u06CC\u062F.");
  const c = structuredClone(original), j = care(c), member = a.role === "member" && a.phone === c.phone, doctor = a.role === "clinician" && a.phone === effectiveDoctor(c) && (c.phase !== "draft" || c.urgent), coord = coordinationAccess(a, c) || a.role === "coordinator" && a.phone === c.coordinator;
  const clinical = () => {
    need(doctor, "\u0627\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0645\u0633\u0626\u0648\u0644 \u0641\u0639\u0644\u06CC \u0627\u0633\u062A.");
    need(!c.urgent, "\u0627\u0628\u062A\u062F\u0627 \u0631\u0633\u06CC\u062F\u06AF\u06CC \u0628\u0647 \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
  };
  const referral = (rid) => {
    const r = j.referrals.find((r2) => r2.id === rid);
    need(r, "\u0627\u0631\u062C\u0627\u0639 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    return r;
  };
  const coordinate = (rid) => {
    const r = referral(rid);
    need(coord && a.phone === r.coordinator, "\u0627\u06CC\u0646 \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0628\u0647 \u0634\u0645\u0627 \u062A\u062E\u0635\u06CC\u0635 \u0646\u062F\u0627\u0631\u062F.");
    need(c.contactConsent, "\u0628\u0631\u0627\u06CC \u0627\u062F\u0627\u0645\u0647\u0654 \u062A\u0645\u0627\u0633\u060C \u0627\u062C\u0627\u0632\u0647\u0654 \u0628\u06CC\u0645\u0627\u0631 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
    return r;
  };
  const report = (fid) => {
    const f = c.files.find((f2) => f2.id === fid);
    need(f, "\u06AF\u0632\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    return f;
  };
  const review = (fid) => {
    const r = j.reviews.find((r2) => r2.fileId === fid);
    need(r, "\u0628\u0631\u0631\u0633\u06CC \u06AF\u0632\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    return r;
  };
  switch (cmd.kind) {
    case "care_history":
      need(member, "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0648\u0644\u06CC\u0647 \u0628\u0627 \u062E\u0648\u062F \u0628\u06CC\u0645\u0627\u0631 \u0627\u0633\u062A.");
      j.history = { medicines: clean(cmd.medicines), allergies: clean(cmd.allergies), other: clean(cmd.other) };
      break;
    case "care_verify_history":
      clinical();
      j.history.verifiedAt = Date.now();
      j.history.verifiedBy = a.phone;
      break;
    case "care_assign":
      need(member && c.phase === "draft", "\u0627\u0646\u062A\u062E\u0627\u0628 \u0627\u0648\u0644\u06CC\u0647\u0654 \u067E\u0632\u0634\u06A9 \u067E\u06CC\u0634 \u0627\u0632 \u0627\u0631\u0633\u0627\u0644 \u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u0646\u062C\u0627\u0645 \u0645\u06CC\u200C\u0634\u0648\u062F.");
      need(doctorPhones.includes(cmd.doctor), "\u067E\u0632\u0634\u06A9 \u0645\u0639\u062A\u0628\u0631 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
      c.doctor = cmd.doctor;
      break;
    case "care_encounter": {
      clinical();
      need(c.tasks.some((t) => t.kind === "visit" && t.status === "completed"), "\u0627\u0628\u062A\u062F\u0627 \u0627\u0646\u062C\u0627\u0645 \u0645\u0644\u0627\u0642\u0627\u062A \u062B\u0628\u062A \u0634\u0648\u062F.");
      let e = j.encounters.find((e2) => e2.id === cmd.id);
      if (!e) {
        e = { id: id(), doctor: a.phone, draft: "", summary: "", versions: [] };
        j.encounters.push(e);
      }
      need(clean(cmd.note) && clean(cmd.summary), "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u0648 \u062E\u0644\u0627\u0635\u0647\u0654 \u0642\u0627\u0628\u0644 \u0641\u0647\u0645 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F.");
      e.draft = clean(cmd.note);
      e.summary = clean(cmd.summary);
      if (cmd.sign) {
        e.versions.push({ id: id(), note: e.draft, summary: e.summary, signedAt: Date.now(), doctor: a.phone });
        notify(c, "encounter:" + e.id);
      }
      break;
    }
    case "care_decide": {
      need(member, "\u062A\u0635\u0645\u06CC\u0645 \u062F\u0631\u0628\u0627\u0631\u0647\u0654 \u0627\u0642\u062F\u0627\u0645 \u0628\u0627 \u062E\u0648\u062F \u0628\u06CC\u0645\u0627\u0631 \u0627\u0633\u062A.");
      const action = c.plans.flatMap((p) => p.actions).find((x) => x.id === cmd.actionId);
      need(action, "\u0627\u0642\u062F\u0627\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
      need(!action.done || cmd.decision === "accepted", "\u0627\u0646\u062C\u0627\u0645 \u0627\u06CC\u0646 \u0642\u062F\u0645 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647\u061B \u062A\u0635\u0645\u06CC\u0645 \u062A\u0627\u0632\u0647 \u0646\u0628\u0627\u06CC\u062F \u0633\u0627\u0628\u0642\u0647\u0654 \u0627\u0646\u062C\u0627\u0645 \u0631\u0627 \u067E\u0627\u06A9 \u06A9\u0646\u062F.");
      need(["accepted", "declined", "deferred"].includes(cmd.decision), "\u062A\u0635\u0645\u06CC\u0645 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
      need(cmd.decision === "accepted" || clean(cmd.reason), "\u062F\u0644\u06CC\u0644 \u06CC\u0627 \u0645\u0627\u0646\u0639 \u0631\u0627 \u06A9\u0648\u062A\u0627\u0647 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      j.decisions[action.id] = { state: cmd.decision, reason: clean(cmd.reason), at: Date.now() };
      if (cmd.decision !== "accepted") {
        action.done = false;
        addResponsibility(c, "decision:" + action.id, "\u0645\u0631\u0648\u0631 \u062A\u0635\u0645\u06CC\u0645 \u0628\u06CC\u0645\u0627\u0631 \u062F\u0631\u0628\u0627\u0631\u0647\u0654 " + action.title, localDay(), "\u062F\u0631\u0628\u0627\u0631\u0647\u0654 \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646 \u06CC\u0627 \u0632\u0645\u0627\u0646 \u062F\u06CC\u06AF\u0631 \u0628\u0627 \u0628\u06CC\u0645\u0627\u0631 \u06AF\u0641\u062A\u200C\u0648\u06AF\u0648 \u06A9\u0646\u06CC\u062F.");
      }
      break;
    }
    case "care_referral": {
      clinical();
      need(["active", "awaiting_plan"].includes(c.phase), "\u067E\u0633 \u0627\u0632 \u0645\u0644\u0627\u0642\u0627\u062A\u060C \u0627\u0631\u062C\u0627\u0639 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
      need(["lab", "specialist", "clinic"].includes(cmd.type) && clean(cmd.title) && clean(cmd.question), "\u0646\u0648\u0639\u060C \u0639\u0646\u0648\u0627\u0646 \u0648 \u062F\u0644\u06CC\u0644 \u0628\u0627\u0644\u06CC\u0646\u06CC \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
      const r = { id: id(), type: cmd.type, title: clean(cmd.title), question: clean(cmd.question), doctor: a.phone, coordinator: c.coordinator, dueAt: due(cmd.dueAt), partner: "", authority: false, status: "requested", contacts: [], specimen: cmd.type === "lab" ? "waiting" : void 0, reportIds: [] };
      j.referrals.push(r);
      addResponsibility(c, "referral:" + r.id, r.title, r.dueAt, "\u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0646\u062A\u06CC\u062C\u0647 \u062A\u0627 \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9");
      break;
    }
    case "care_authorize": {
      need(member, "\u0627\u062C\u0627\u0632\u0647\u0654 \u0627\u0634\u062A\u0631\u0627\u06A9 \u0631\u0627 \u062E\u0648\u062F \u0628\u06CC\u0645\u0627\u0631 \u0645\u0634\u062E\u0635 \u0645\u06CC\u200C\u06A9\u0646\u062F.");
      const r = referral(cmd.referralId);
      need(r.status !== "closed" && r.partner, "\u0627\u0628\u062A\u062F\u0627 \u0645\u0631\u06A9\u0632 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0645\u0634\u062E\u0635 \u0634\u0648\u062F.");
      r.authority = cmd.value;
      (r.authorityHistory ??= []).push({ recipient: r.partner, value: cmd.value, actor: a.phone, at: Date.now() });
      break;
    }
    case "care_referral_step": {
      need(["contact", "partner", "send", "accept", "reject", "book", "attend", "collect", "reject_specimen", "close"].includes(cmd.step), "\u0645\u0631\u062D\u0644\u0647\u0654 \u0627\u0631\u062C\u0627\u0639 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
      const r = cmd.step === "close" ? (clinical(), referral(cmd.referralId)) : coordinate(cmd.referralId);
      need(clean(cmd.text), "\u0634\u0627\u0647\u062F \u06CC\u0627 \u0646\u062A\u06CC\u062C\u0647\u0654 \u0627\u0642\u062F\u0627\u0645 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      r.contacts.push({ at: Date.now(), text: clean(cmd.text) });
      switch (cmd.step) {
        case "contact":
          break;
        case "partner":
          need(["requested", "rejected"].includes(r.status) && clean(cmd.partner || ""), "\u0645\u0631\u06A9\u0632 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0631\u0627 \u0645\u0634\u062E\u0635 \u06A9\u0646\u06CC\u062F.");
          r.partner = clean(cmd.partner);
          r.authority = false;
          break;
        case "send":
          need(r.authority && r.partner === clean(cmd.partner || "") && ["requested", "rejected"].includes(r.status) && clean(cmd.partner || ""), "\u0627\u0628\u062A\u062F\u0627 \u0627\u062C\u0627\u0632\u0647\u0654 \u0627\u0634\u062A\u0631\u0627\u06A9 \u0648 \u0646\u0627\u0645 \u0645\u0631\u06A9\u0632 \u0645\u0634\u062E\u0635 \u0634\u0648\u062F.");
          r.partner = clean(cmd.partner);
          r.status = "sent";
          break;
        case "accept":
          need(r.status === "sent", "\u0627\u0628\u062A\u062F\u0627 \u0627\u0631\u0633\u0627\u0644 \u0648\u0627\u0642\u0639\u06CC \u062B\u0628\u062A \u0634\u0648\u062F.");
          r.status = "accepted";
          break;
        case "reject":
          need(["sent", "accepted"].includes(r.status), "\u0627\u0631\u062C\u0627\u0639 \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u067E\u0627\u0633\u062E \u0645\u0631\u06A9\u0632 \u0646\u06CC\u0633\u062A.");
          r.status = "rejected";
          break;
        case "book":
          need(["accepted", "booked"].includes(r.status), "\u0627\u0628\u062A\u062F\u0627 \u067E\u0630\u06CC\u0631\u0634 \u0645\u0631\u06A9\u0632 \u062B\u0628\u062A \u0634\u0648\u062F.");
          r.date = due(cmd.date || "");
          need(r.date >= (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "Asia/Tehran" }), "\u062A\u0627\u0631\u06CC\u062E \u0627\u0645\u0631\u0648\u0632 \u06CC\u0627 \u0622\u06CC\u0646\u062F\u0647 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
          need(/^([01]\d|2[0-3]):[0-5]\d$/.test(cmd.time || ""), "\u0633\u0627\u0639\u062A \u0645\u0639\u062A\u0628\u0631 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.");
          r.time = cmd.time;
          r.patientConfirmed = false;
          r.status = "booked";
          break;
        case "attend":
          need(r.status === "booked" && r.patientConfirmed, "\u0632\u0645\u0627\u0646 \u0628\u0627\u06CC\u062F \u0628\u0647 \u062A\u0623\u06CC\u06CC\u062F \u0628\u06CC\u0645\u0627\u0631 \u0631\u0633\u06CC\u062F\u0647 \u0628\u0627\u0634\u062F.");
          r.status = "attended";
          break;
        case "collect":
        case "reject_specimen":
          need(r.type === "lab" && r.status === "attended", "\u0648\u0636\u0639\u06CC\u062A \u0646\u0645\u0648\u0646\u0647 \u067E\u0633 \u0627\u0632 \u0645\u0631\u0627\u062C\u0639\u0647\u0654 \u0622\u0632\u0645\u0627\u06CC\u0634 \u062B\u0628\u062A \u0645\u06CC\u200C\u0634\u0648\u062F.");
          r.specimen = cmd.step === "collect" ? "collected" : "rejected";
          break;
        case "close":
          need(!j.reports.some((m) => m.referralId === r.id && m.quarantined), "\u06AF\u0632\u0627\u0631\u0634 \u0646\u0627\u0645\u0637\u0645\u0626\u0646 \u0627\u06CC\u0646 \u0627\u0631\u062C\u0627\u0639 \u0647\u0646\u0648\u0632 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u062A\u0639\u06CC\u06CC\u0646 \u062A\u06A9\u0644\u06CC\u0641 \u062F\u0627\u0631\u062F.");
          need(r.reportIds.length > 0 && r.reportIds.filter((fid) => !j.reports.some((m) => m.supersedes === fid)).every((fid) => j.reviews.some((v) => v.fileId === fid && v.publishedAt)), "\u0627\u0628\u062A\u062F\u0627 \u06AF\u0632\u0627\u0631\u0634\u200C\u0647\u0627 \u0628\u0631\u0631\u0633\u06CC \u0648 \u062A\u0648\u0636\u06CC\u062D \u0645\u0646\u062A\u0634\u0631 \u0634\u0648\u0646\u062F.");
          need(!j.responsibilities.some((v) => v.state === "open" && v.subject.startsWith("followup:") && r.reportIds.includes(v.subject.slice(9))), "\u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0628\u0627\u0644\u06CC\u0646\u06CC \u06AF\u0632\u0627\u0631\u0634 \u0647\u0646\u0648\u0632 \u0628\u0627\u0632 \u0627\u0633\u062A.");
          r.status = "closed";
          for (const x of j.responsibilities.filter((x2) => x2.subject === "referral:" + r.id)) {
            x.state = "resolved";
            x.resolution = clean(cmd.text);
          }
          break;
      }
      r.evidence = clean(cmd.text);
      break;
    }
    case "care_confirm_referral": {
      need(member, "\u0632\u0645\u0627\u0646 \u0645\u0631\u0627\u062C\u0639\u0647 \u0631\u0627 \u0628\u06CC\u0645\u0627\u0631 \u062A\u0623\u06CC\u06CC\u062F \u0645\u06CC\u200C\u06A9\u0646\u062F.");
      const r = referral(cmd.referralId);
      need(r.status === "booked", "\u0632\u0645\u0627\u0646 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F.");
      r.patientConfirmed = cmd.accept;
      if (!cmd.accept) r.status = "accepted";
      break;
    }
    case "care_report": {
      need(member || coord, "\u0627\u062C\u0627\u0632\u0647\u0654 \u062F\u0631\u06CC\u0627\u0641\u062A \u06AF\u0632\u0627\u0631\u0634 \u0646\u062F\u0627\u0631\u06CC\u062F.");
      const f = cmd.file;
      need(f.blob instanceof Blob && f.blob.size > 0 && f.blob.size <= 10 * 1024 * 1024 && ["application/pdf", "image/png", "image/jpeg"].includes(f.mime), "\u0641\u0627\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u062A\u0627 \u06F1\u06F0 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
      need(clean(cmd.provider) && clean(cmd.externalId), "\u0645\u0646\u0628\u0639 \u0648 \u0634\u0646\u0627\u0633\u0647\u0654 \u06AF\u0632\u0627\u0631\u0634 \u0631\u0627 \u0645\u0634\u062E\u0635 \u06A9\u0646\u06CC\u062F.");
      need(!j.reports.some((m) => m.provider === clean(cmd.provider) && m.externalId === clean(cmd.externalId)), "\u0627\u06CC\u0646 \u0631\u0648\u06CC\u062F\u0627\u062F \u06AF\u0632\u0627\u0631\u0634 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A.");
      let r;
      if (cmd.referralId) {
        r = referral(cmd.referralId);
        need(member || a.phone === r.coordinator, "\u0627\u0631\u062C\u0627\u0639 \u0628\u0647 \u0627\u06CC\u0646 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u062A\u062E\u0635\u06CC\u0635 \u0646\u062F\u0627\u0631\u062F.");
        if (!cmd.uncertain) need(r.status === "attended" || r.status === "reported", "\u0627\u0628\u062A\u062F\u0627 \u0645\u0631\u0627\u062C\u0639\u0647 \u062B\u0628\u062A \u0634\u0648\u062F.");
        if (r.type === "lab" && !cmd.uncertain) need(r.specimen === "collected", "\u0627\u0628\u062A\u062F\u0627 \u062F\u0631\u06CC\u0627\u0641\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u0645\u0639\u062A\u0628\u0631 \u062B\u0628\u062A \u0634\u0648\u062F.");
      } else need(member, "\u06AF\u0632\u0627\u0631\u0634 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0628\u0627\u06CC\u062F \u0628\u0647 \u0627\u0631\u062C\u0627\u0639 \u0645\u0634\u062E\u0635 \u0645\u0631\u062A\u0628\u0637 \u0628\u0627\u0634\u062F.");
      if (cmd.supersedes) {
        const old = j.reports.find((m) => m.fileId === cmd.supersedes);
        need(old && !old.quarantined && old.referralId === cmd.referralId, "\u06AF\u0632\u0627\u0631\u0634 \u0642\u0628\u0644\u06CC \u0647\u0645\u06CC\u0646 \u0627\u0631\u062C\u0627\u0639 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
        need(!j.reports.some((m) => m.supersedes === cmd.supersedes), "\u0627\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0642\u0628\u0644\u0627\u064B \u0627\u0635\u0644\u0627\u062D \u0634\u062F\u0647\u061B \u0622\u062E\u0631\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
      }
      if (cmd.supersedes && !cmd.uncertain) {
        for (const x of j.responsibilities.filter((x2) => x2.subject === "report:" + cmd.supersedes && x2.state === "open")) {
          x.state = "resolved";
          x.resolution = "\u0646\u0633\u062E\u0647\u0654 \u062A\u0627\u0632\u0647 \u062C\u0627\u06CC\u06AF\u0632\u06CC\u0646 \u0634\u062F\u061B \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0628\u0631\u0631\u0633\u06CC \u062A\u0627\u0632\u0647 \u0627\u06CC\u062C\u0627\u062F \u0645\u06CC\u200C\u0634\u0648\u062F.";
        }
      }
      need(!c.files.some((x) => x.id === f.id), "\u0634\u0646\u0627\u0633\u0647\u0654 \u0641\u0627\u06CC\u0644 \u062A\u06A9\u0631\u0627\u0631\u06CC \u0627\u0633\u062A.");
      c.files.push({ ...f, createdAt: Date.now(), source: member ? "member" : "coordinator", review: void 0, fixture: void 0 });
      j.reports.push({ fileId: f.id, referralId: cmd.referralId, provider: clean(cmd.provider), externalId: clean(cmd.externalId), supersedes: cmd.supersedes, quarantined: cmd.uncertain, checksum: f.checksum || "", reportedAt: Date.now() });
      if (!cmd.uncertain) {
        if (r) {
          r.reportIds.push(f.id);
          r.status = "reported";
        }
        addResponsibility(c, "report:" + f.id, cmd.supersedes ? "\u0628\u0631\u0631\u0633\u06CC \u06AF\u0632\u0627\u0631\u0634 \u0627\u0635\u0644\u0627\u062D\u200C\u0634\u062F\u0647" : "\u0628\u0631\u0631\u0633\u06CC \u06AF\u0632\u0627\u0631\u0634 \u062A\u0627\u0632\u0647", r?.dueAt || localDay(), "\u0628\u0631\u0631\u0633\u06CC \u0647\u0645\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0648 \u062A\u0639\u06CC\u06CC\u0646 \u0642\u062F\u0645 \u0628\u0639\u062F");
      } else addResponsibility(c, "match:" + f.id, "\u062A\u0639\u06CC\u06CC\u0646 \u062A\u06A9\u0644\u06CC\u0641 \u06AF\u0632\u0627\u0631\u0634 \u0628\u0627 \u062A\u0637\u0628\u06CC\u0642 \u0646\u0627\u0645\u0637\u0645\u0626\u0646", localDay(), "\u067E\u06CC\u0634 \u0627\u0632 \u0646\u0645\u0627\u06CC\u0634 \u0628\u06CC\u0645\u0627\u0631\u060C \u0645\u0646\u0628\u0639 \u0648 \u0627\u0631\u062A\u0628\u0627\u0637 \u06AF\u0632\u0627\u0631\u0634 \u0631\u0648\u0634\u0646 \u0634\u0648\u062F.");
      break;
    }
    case "care_match_report": {
      clinical();
      const m = j.reports.find((m2) => m2.fileId === cmd.fileId);
      need(m?.quarantined && clean(cmd.text), "\u0634\u0627\u0647\u062F \u062A\u0637\u0628\u06CC\u0642 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
      m.quarantined = false;
      if (m.supersedes) {
        for (const old of j.responsibilities.filter((r) => r.subject === "report:" + m.supersedes && r.state === "open")) {
          old.state = "resolved";
          old.resolution = "\u062A\u0637\u0628\u06CC\u0642 \u0646\u0633\u062E\u0647\u0654 \u0627\u0635\u0644\u0627\u062D\u200C\u0634\u062F\u0647 \u062A\u0623\u06CC\u06CC\u062F \u0648 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0628\u0631\u0631\u0633\u06CC \u0628\u0647 \u0646\u0633\u062E\u0647\u0654 \u062A\u0627\u0632\u0647 \u0645\u0646\u062A\u0642\u0644 \u0634\u062F.";
        }
      }
      if (m.referralId) {
        const r = referral(m.referralId);
        r.reportIds.push(m.fileId);
        r.status = "reported";
      }
      for (const r of j.responsibilities.filter((r2) => r2.subject === "match:" + cmd.fileId)) {
        r.state = "resolved";
        r.resolution = clean(cmd.text);
      }
      addResponsibility(c, "report:" + cmd.fileId, "\u0628\u0631\u0631\u0633\u06CC \u06AF\u0632\u0627\u0631\u0634 \u062A\u0637\u0628\u06CC\u0642\u200C\u062F\u0627\u062F\u0647\u200C\u0634\u062F\u0647", localDay(), "\u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9");
      break;
    }
    case "care_review": {
      clinical();
      report(cmd.fileId);
      need(!j.reports.find((m) => m.fileId === cmd.fileId)?.quarantined, "\u06AF\u0632\u0627\u0631\u0634 \u0627\u0628\u062A\u062F\u0627 \u0628\u0627\u06CC\u062F \u062A\u0637\u0628\u06CC\u0642 \u062F\u0627\u062F\u0647 \u0634\u0648\u062F.");
      need(!j.reports.some((m) => m.supersedes === cmd.fileId), "\u0646\u0633\u062E\u0647\u0654 \u0627\u0635\u0644\u0627\u062D\u200C\u0634\u062F\u0647 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F\u061B \u0646\u0633\u062E\u0647\u0654 \u062A\u0627\u0632\u0647 \u0631\u0627 \u0628\u0631\u0631\u0633\u06CC \u06A9\u0646\u06CC\u062F.");
      need(clean(cmd.note) && clean(cmd.explanation), "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u0628\u0627\u0644\u06CC\u0646\u06CC \u0648 \u062A\u0648\u0636\u06CC\u062D \u0628\u06CC\u0645\u0627\u0631 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F.");
      let r = j.reviews.find((r2) => r2.fileId === cmd.fileId);
      need(!r?.signedAt, "\u0628\u0631\u0631\u0633\u06CC \u0627\u0645\u0636\u0627\u0634\u062F\u0647 \u0642\u0627\u0628\u0644 \u0628\u0627\u0632\u0646\u0648\u06CC\u0633\u06CC \u0646\u06CC\u0633\u062A\u061B \u0627\u0635\u0644\u0627\u062D \u06AF\u0632\u0627\u0631\u0634 \u0646\u0633\u062E\u0647\u0654 \u062A\u0627\u0632\u0647 \u0645\u06CC\u200C\u062E\u0648\u0627\u0647\u062F.");
      if (!r) {
        r = { fileId: cmd.fileId, doctor: a.phone, note: "", explanation: "", delivery: "pending", attempts: 0, followup: "" };
        j.reviews.push(r);
      }
      r.note = clean(cmd.note);
      r.explanation = clean(cmd.explanation);
      r.followup = clean(cmd.followup);
      if (cmd.sign) {
        r.signedAt = Date.now();
        r.doctor = a.phone;
        for (const x of j.responsibilities.filter((x2) => x2.subject === "report:" + cmd.fileId)) {
          x.state = "resolved";
          x.resolution = "\u0628\u0631\u0631\u0633\u06CC \u0627\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0627\u0645\u0636\u0627 \u0634\u062F\u061B \u0627\u0646\u062A\u0634\u0627\u0631 \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u062C\u062F\u0627\u06AF\u0627\u0646\u0647\u200C\u0627\u0646\u062F.";
        }
        addResponsibility(c, "publish:" + cmd.fileId, "\u0627\u0646\u062A\u0634\u0627\u0631 \u062A\u0648\u0636\u06CC\u062D \u0628\u0631\u0631\u0633\u06CC\u200C\u0634\u062F\u0647", due(cmd.dueAt), "\u062A\u0648\u0636\u06CC\u062D \u0647\u0645\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0631\u0627 \u0628\u0631\u0627\u06CC \u0628\u06CC\u0645\u0627\u0631 \u0645\u0646\u062A\u0634\u0631 \u06A9\u0646\u06CC\u062F.");
        if (r.followup) addResponsibility(c, "followup:" + cmd.fileId, r.followup, due(cmd.dueAt), "\u0646\u062A\u06CC\u062C\u0647\u0654 \u0627\u0642\u062F\u0627\u0645 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0631\u0627 \u062C\u062F\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
      }
      break;
    }
    case "care_publish_review": {
      clinical();
      const r = review(cmd.fileId);
      need(r.signedAt && !r.publishedAt, "\u0627\u0628\u062A\u062F\u0627 \u0628\u0631\u0631\u0633\u06CC \u0627\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0627\u0645\u0636\u0627 \u0634\u0648\u062F.");
      r.publishedAt = Date.now();
      for (const x of j.responsibilities.filter((x2) => x2.subject === "publish:" + cmd.fileId && x2.state === "open")) {
        x.state = "resolved";
        x.resolution = "\u062A\u0648\u0636\u06CC\u062D \u0647\u0645\u06CC\u0646 \u0646\u0633\u062E\u0647 \u0628\u0631\u0627\u06CC \u0628\u06CC\u0645\u0627\u0631 \u0645\u0646\u062A\u0634\u0631 \u0634\u062F.";
      }
      report(cmd.fileId).review = { doctor: r.doctor, text: r.explanation, at: r.publishedAt };
      notify(c, "report:" + cmd.fileId);
      break;
    }
    case "care_delivery": {
      need(a.role === "admin" || doctor, "\u062B\u0628\u062A \u0648\u0636\u0639\u06CC\u062A \u062A\u062D\u0648\u06CC\u0644 \u0628\u0627 \u0639\u0645\u0644\u06CC\u0627\u062A \u06CC\u0627 \u067E\u0632\u0634\u06A9 \u0627\u0633\u062A.");
      const n = j.notifications.findLast((n2) => n2.subject === cmd.subject);
      need(n && n.state !== "delivered", "\u067E\u06CC\u0627\u0645 \u0642\u0627\u0628\u0644 \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
      need(["failed", "delivered"].includes(cmd.outcome), "\u0648\u0636\u0639\u06CC\u062A \u062A\u062D\u0648\u06CC\u0644 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
      n.state = cmd.outcome;
      n.attempts++;
      const fid = cmd.subject.startsWith("report:") ? cmd.subject.slice(7) : "";
      const r = j.reviews.find((r2) => r2.fileId === fid);
      if (r) {
        r.delivery = cmd.outcome;
        r.attempts++;
      }
      break;
    }
    case "care_ack": {
      need(member, "\u062A\u0623\u06CC\u06CC\u062F \u062F\u06CC\u062F\u0646 \u0628\u0627 \u062E\u0648\u062F \u0628\u06CC\u0645\u0627\u0631 \u0627\u0633\u062A.");
      const r = review(cmd.fileId);
      need(r.publishedAt, "\u062A\u0648\u0636\u06CC\u062D \u0647\u0646\u0648\u0632 \u0645\u0646\u062A\u0634\u0631 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
      r.ackAt = Date.now();
      break;
    }
    case "care_resolve": {
      clinical();
      const r = j.responsibilities.find((r2) => r2.id === cmd.id);
      need(r && r.state === "open" && r.owner === a.phone && clean(cmd.text), "\u0646\u062A\u06CC\u062C\u0647\u0654 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0628\u0627\u0632 \u062E\u0648\u062F\u062A\u0627\u0646 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      need(!r.subject.startsWith("report:") && !r.subject.startsWith("match:") && !r.subject.startsWith("referral:") && !r.subject.startsWith("publish:"), "\u0627\u06CC\u0646 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0627\u0632 \u06AF\u0631\u062F\u0634 \u0628\u0631\u0631\u0633\u06CC \u06AF\u0632\u0627\u0631\u0634 \u06CC\u0627 \u0627\u0631\u062C\u0627\u0639 \u062A\u06A9\u0645\u06CC\u0644 \u0645\u06CC\u200C\u0634\u0648\u062F.");
      r.state = "resolved";
      r.resolution = clean(cmd.text);
      break;
    }
    case "care_escalate": {
      need(doctor || coord, "\u0627\u062C\u0627\u0632\u0647\u0654 \u0627\u0631\u062C\u0627\u0639 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0646\u062F\u0627\u0631\u06CC\u062F.");
      const r = j.responsibilities.find((r2) => r2.id === cmd.id);
      need(r && r.state === "open" && clean(cmd.text), "\u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0628\u0627\u0632 \u0648 \u062A\u0648\u0636\u06CC\u062D \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
      r.escalated = true;
      r.next = clean(cmd.text);
      break;
    }
    case "care_cover": {
      clinical();
      need(doctorPhones.includes(cmd.to) && cmd.to !== a.phone && clean(cmd.reason), "\u067E\u0632\u0634\u06A9 \u062F\u06CC\u06AF\u0631 \u0648 \u062F\u0644\u06CC\u0644 \u0631\u0627 \u0645\u0634\u062E\u0635 \u06A9\u0646\u06CC\u062F.");
      need(!j.handovers.some((h) => h.state === "requested"), "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062C\u0627\u0646\u0634\u06CC\u0646\u06CC \u0628\u0627\u0632 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F.");
      j.handovers.push({ id: id(), from: a.phone, to: cmd.to, reason: clean(cmd.reason), until: due(cmd.until), state: "requested", at: Date.now() });
      break;
    }
    case "care_cover_reply": {
      const h = j.handovers.find((h2) => h2.id === cmd.id);
      need(a.role === "clinician" && h?.to === a.phone && h.state === "requested", "\u0627\u06CC\u0646 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u0628\u0631\u0627\u06CC \u0634\u0645\u0627 \u0628\u0627\u0632 \u0646\u06CC\u0633\u062A.");
      h.state = cmd.accept ? "accepted" : "declined";
      if (cmd.accept) {
        h.acceptedAt = Date.now();
        for (const r of j.responsibilities.filter((r2) => r2.state === "open")) r.owner = a.phone;
      }
      break;
    }
    case "care_cover_return": {
      clinical();
      const h = j.handovers.find((h2) => h2.id === cmd.id);
      need(h?.state === "accepted" && h.to === a.phone && clean(cmd.text), "\u062C\u0627\u0646\u0634\u06CC\u0646\u06CC \u0641\u0639\u0627\u0644 \u0648 \u062A\u0648\u0636\u06CC\u062D \u062A\u062D\u0648\u06CC\u0644 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
      need(!j.handovers.some((v) => v.state === "requested"), "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u0632 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F.");
      j.handovers.push({ id: id(), from: a.phone, to: c.doctor, reason: clean(cmd.text), until: localDay(), state: "requested", at: Date.now() });
      break;
    }
    case "care_barrier": {
      need(member && c.phase !== "draft" && clean(cmd.text), "\u0645\u0627\u0646\u0639 \u0631\u0627 \u067E\u0633 \u0627\u0632 \u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647 \u06A9\u0648\u062A\u0627\u0647 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      const b = { id: id(), type: clean(cmd.type), text: clean(cmd.text), owner: c.coordinator, dueAt: due(cmd.dueAt), state: "open", proposal: "" };
      j.barriers.push(b);
      break;
    }
    case "care_barrier_propose": {
      const b = j.barriers.find((b2) => b2.id === cmd.id);
      need(coord && b?.owner === a.phone && ["open", "proposed", "escalated"].includes(b.state) && clean(cmd.text), "\u0645\u0627\u0646\u0639 \u0628\u0627\u0632 \u062E\u0648\u062F\u062A\u0627\u0646 \u0648 \u067E\u0627\u0633\u062E \u0631\u0627 \u0645\u0634\u062E\u0635 \u06A9\u0646\u06CC\u062F.");
      b.proposal = clean(cmd.text);
      b.state = cmd.escalate ? "escalated" : "proposed";
      if (cmd.escalate) addResponsibility(c, "barrier:" + b.id, "\u0645\u0631\u0648\u0631 \u0645\u0627\u0646\u0639 \u0628\u06CC\u0645\u0627\u0631", b.dueAt, b.proposal);
      break;
    }
    case "care_barrier_accept": {
      need(member, "\u062A\u0623\u06CC\u06CC\u062F \u0631\u0627\u0647\u200C\u062D\u0644 \u0628\u0627 \u0628\u06CC\u0645\u0627\u0631 \u0627\u0633\u062A.");
      const b = j.barriers.find((b2) => b2.id === cmd.id);
      need(b?.state === "proposed", "\u0631\u0627\u0647\u200C\u062D\u0644 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0628\u0627\u0632 \u0646\u06CC\u0633\u062A.");
      b.state = cmd.accept ? "resolved" : "open";
      if (cmd.accept) b.resolution = b.proposal;
      break;
    }
    case "care_purchase": {
      need(!c.urgent, "\u0627\u0628\u062A\u062F\u0627 \u0631\u0633\u06CC\u062F\u06AF\u06CC \u067E\u0632\u0634\u06A9 \u0628\u0647 \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631 \u062B\u0628\u062A \u0634\u0648\u062F.");
      need(member && c.phase !== "draft", "\u062E\u0631\u06CC\u062F \u0646\u0645\u0627\u06CC\u0634\u06CC \u067E\u0633 \u0627\u0632 \u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647 \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0627\u0633\u062A.");
      need(["success", "failed", "cancelled"].includes(cmd.outcome), "\u0646\u062A\u06CC\u062C\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
      need(j.membership.state !== "cancel_requested", "\u0627\u0628\u062A\u062F\u0627 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0644\u063A\u0648 \u062A\u0639\u06CC\u06CC\u0646 \u062A\u06A9\u0644\u06CC\u0641 \u0634\u0648\u062F.");
      j.membership.receipts.push({ id: id(), at: Date.now(), amount: 12e5, outcome: cmd.outcome });
      if (cmd.outcome === "success") {
        j.membership.state = "active";
        j.membership.endsAt = Math.max(Date.now(), j.membership.endsAt || 0) + 30 * 864e5;
      }
      break;
    }
    case "care_cancel_membership": {
      need(member && j.membership.state === "active" && clean(cmd.reason), "\u0644\u063A\u0648 \u0639\u0636\u0648\u06CC\u062A \u0641\u0639\u0627\u0644 \u0628\u0627 \u0630\u06A9\u0631 \u062F\u0644\u06CC\u0644 \u062B\u0628\u062A \u0645\u06CC\u200C\u0634\u0648\u062F.");
      j.membership.state = "cancel_requested";
      addResponsibility(c, "continuity", "\u0645\u0631\u0648\u0631 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A\u200C\u0647\u0627\u06CC \u0628\u0627\u0632 \u067E\u06CC\u0634 \u0627\u0632 \u067E\u0627\u06CC\u0627\u0646 \u0639\u0636\u0648\u06CC\u062A", localDay(), clean(cmd.reason));
      break;
    }
    case "care_end_membership": {
      clinical();
      need(j.membership.state === "cancel_requested" && clean(cmd.text), "\u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u0627\u062F\u0627\u0645\u0647\u0654 \u0645\u0631\u0627\u0642\u0628\u062A \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      need(!j.responsibilities.some((r) => r.state === "open" && r.subject !== "continuity"), "\u0627\u0628\u062A\u062F\u0627 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A\u200C\u0647\u0627\u06CC \u0628\u0627\u0632 \u0631\u0627 \u062D\u0644 \u06CC\u0627 \u0628\u0627 \u067E\u0630\u06CC\u0631\u0634 \u0628\u0647 \u062C\u0627\u0646\u0634\u06CC\u0646 \u0645\u0646\u062A\u0642\u0644 \u06A9\u0646\u06CC\u062F\u061B \u0628\u0633\u062A\u0646 \u0635\u0648\u0631\u06CC \u0645\u062C\u0627\u0632 \u0646\u06CC\u0633\u062A.");
      need(j.notifications.every((n) => n.state === "delivered" || n.subject.startsWith("report:") && j.reviews.some((r) => "report:" + r.fileId === n.subject && r.ackAt)), "\u0627\u0637\u0644\u0627\u0639\u200C\u0631\u0633\u0627\u0646\u06CC \u0628\u0627\u0632 \u0631\u0627 \u062A\u0639\u06CC\u06CC\u0646 \u062A\u06A9\u0644\u06CC\u0641 \u06A9\u0646\u06CC\u062F\u061B \u067E\u0627\u06CC\u0627\u0646 \u0645\u0627\u0644\u06CC \u0646\u0628\u0627\u06CC\u062F \u0627\u0631\u062A\u0628\u0627\u0637 \u0645\u0631\u0627\u0642\u0628\u062A \u0631\u0627 \u0631\u0647\u0627 \u06A9\u0646\u062F.");
      j.membership.continuityNote = clean(cmd.text);
      j.membership.state = "cancelled";
      for (const r of j.responsibilities.filter((r2) => r2.subject === "continuity")) {
        r.state = "resolved";
        r.resolution = clean(cmd.text);
      }
      break;
    }
    default:
      throw Error("\u0627\u0642\u062F\u0627\u0645 \u0646\u0627\u0634\u0646\u0627\u062E\u062A\u0647 \u0627\u0633\u062A.");
  }
  c.version++;
  c.events.push({ id: id(), at: Date.now(), title: careEvent(cmd.kind), actor: a.name, kind: member ? "member" : a.role === "clinician" ? "doctor" : "team" });
  return c;
}
function careEvent(kind) {
  return { care_history: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062A\u06A9\u0645\u06CC\u0644\u06CC \u0627\u0632 \u0632\u0628\u0627\u0646 \u0628\u06CC\u0645\u0627\u0631 \u062B\u0628\u062A \u0634\u062F", care_verify_history: "\u067E\u0632\u0634\u06A9 \u0645\u0631\u0648\u0631 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062A\u06A9\u0645\u06CC\u0644\u06CC \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F", care_assign: "\u067E\u0632\u0634\u06A9 \u0627\u0648\u0644\u06CC\u0647 \u0627\u0646\u062A\u062E\u0627\u0628 \u0634\u062F", care_encounter: "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u0645\u0644\u0627\u0642\u0627\u062A \u0630\u062E\u06CC\u0631\u0647 \u0634\u062F", care_decide: "\u062A\u0635\u0645\u06CC\u0645 \u0628\u06CC\u0645\u0627\u0631 \u062F\u0631\u0628\u0627\u0631\u0647\u0654 \u0628\u0631\u0646\u0627\u0645\u0647 \u062B\u0628\u062A \u0634\u062F", care_referral: "\u0627\u0631\u062C\u0627\u0639 \u0628\u0627 \u0645\u0633\u0626\u0648\u0644 \u0648 \u0645\u0648\u0639\u062F \u0645\u0634\u062E\u0635 \u062B\u0628\u062A \u0634\u062F", care_authorize: "\u0627\u062C\u0627\u0632\u0647\u0654 \u0627\u0634\u062A\u0631\u0627\u06A9 \u0627\u0631\u062C\u0627\u0639 \u0628\u0647\u200C\u0631\u0648\u0632 \u0634\u062F", care_referral_step: "\u067E\u06CC\u0634\u0631\u0641\u062A \u0627\u0631\u062C\u0627\u0639 \u0628\u0627 \u0634\u0627\u0647\u062F \u062B\u0628\u062A \u0634\u062F", care_confirm_referral: "\u067E\u0627\u0633\u062E \u0628\u06CC\u0645\u0627\u0631 \u0628\u0647 \u0632\u0645\u0627\u0646 \u0627\u0631\u062C\u0627\u0639 \u062B\u0628\u062A \u0634\u062F", care_report: "\u0646\u0633\u062E\u0647\u0654 \u06AF\u0632\u0627\u0631\u0634 \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F", care_match_report: "\u062A\u0637\u0628\u06CC\u0642 \u06AF\u0632\u0627\u0631\u0634 \u0628\u0631\u0631\u0633\u06CC \u0634\u062F", care_review: "\u0628\u0631\u0631\u0633\u06CC \u0647\u0645\u06CC\u0646 \u0646\u0633\u062E\u0647\u0654 \u06AF\u0632\u0627\u0631\u0634 \u062B\u0628\u062A \u0634\u062F", care_publish_review: "\u062A\u0648\u0636\u06CC\u062D \u06AF\u0632\u0627\u0631\u0634 \u0628\u0631\u0627\u06CC \u0628\u06CC\u0645\u0627\u0631 \u0645\u0646\u062A\u0634\u0631 \u0634\u062F", care_delivery: "\u062A\u0644\u0627\u0634 \u062A\u062D\u0648\u06CC\u0644 \u0627\u0637\u0644\u0627\u0639\u200C\u0631\u0633\u0627\u0646\u06CC \u062B\u0628\u062A \u0634\u062F", care_ack: "\u0628\u06CC\u0645\u0627\u0631 \u062F\u06CC\u062F\u0646 \u062A\u0648\u0636\u06CC\u062D \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F", care_resolve: "\u0646\u062A\u06CC\u062C\u0647\u0654 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u062B\u0628\u062A \u0634\u062F", care_escalate: "\u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0628\u0647 \u0645\u0633\u0626\u0648\u0644 \u0627\u0631\u062C\u0627\u0639 \u0634\u062F", care_cover: "\u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u062A\u062D\u0648\u06CC\u0644 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u062B\u0628\u062A \u0634\u062F", care_cover_reply: "\u067E\u0627\u0633\u062E \u067E\u0632\u0634\u06A9 \u0628\u0647 \u062A\u062D\u0648\u06CC\u0644 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u062B\u0628\u062A \u0634\u062F", care_cover_return: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u062F\u0646 \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u062B\u0628\u062A \u0634\u062F", care_barrier: "\u0645\u0627\u0646\u0639 \u0628\u06CC\u0645\u0627\u0631 \u0628\u0631\u0627\u06CC \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u062B\u0628\u062A \u0634\u062F", care_barrier_propose: "\u067E\u0627\u0633\u062E \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0628\u0647 \u0645\u0627\u0646\u0639 \u062B\u0628\u062A \u0634\u062F", care_barrier_accept: "\u067E\u0627\u0633\u062E \u0628\u06CC\u0645\u0627\u0631 \u0628\u0647 \u0631\u0627\u0647\u200C\u062D\u0644 \u062B\u0628\u062A \u0634\u062F", care_purchase: "\u0646\u062A\u06CC\u062C\u0647\u0654 \u062E\u0631\u06CC\u062F \u0646\u0645\u0627\u06CC\u0634\u06CC \u062B\u0628\u062A \u0634\u062F", care_cancel_membership: "\u0644\u063A\u0648 \u0639\u0636\u0648\u06CC\u062A \u0648 \u0645\u0631\u0648\u0631 \u0645\u0631\u0627\u0642\u0628\u062A \u0628\u0627\u0632 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0634\u062F", care_end_membership: "\u067E\u0627\u06CC\u0627\u0646 \u0639\u0636\u0648\u06CC\u062A \u0628\u0627 \u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u0627\u062F\u0627\u0645\u0647\u0654 \u0645\u0631\u0627\u0642\u0628\u062A \u062B\u0628\u062A \u0634\u062F" }[kind];
}
function syncLegacy(c, cmd) {
  const j = care(c);
  if (cmd.kind === "publish") {
    for (const a of c.plans.at(-1).actions) addResponsibility(c, "action:" + a.id, a.title, a.dueAt || localDay(), a.why);
  }
  if (cmd.kind === "upload") {
    addResponsibility(c, "report:" + cmd.file.id, "\u0628\u0631\u0631\u0633\u06CC \u0645\u062F\u0631\u06A9 \u062F\u0631\u06CC\u0627\u0641\u062A\u200C\u0634\u062F\u0647", localDay(), "\u0628\u0631\u0631\u0633\u06CC \u0627\u0635\u0644 \u06AF\u0632\u0627\u0631\u0634");
  }
  if (cmd.kind === "review_file") {
    for (const r of j.responsibilities.filter((r2) => r2.subject === "report:" + cmd.fileId)) {
      r.state = "resolved";
      r.resolution = "\u0628\u0631\u0631\u0633\u06CC \u0633\u0627\u0632\u06AF\u0627\u0631 \u0628\u0627 \u0646\u0633\u062E\u0647\u0654 \u0642\u0628\u0644\u06CC \u062B\u0628\u062A \u0634\u062F";
    }
  }
}
function preflight(snapshot, c, a, cmd) {
  if (cmd.kind === "submit") need(snapshot.cases.filter((x) => x.phone !== c.phone && x.doctor === c.doctor && x.phase !== "draft").length < 20, "\u0638\u0631\u0641\u06CC\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u067E\u0632\u0634\u06A9 \u067E\u0631 \u0627\u0633\u062A.");
  if ("taskId" in cmd) {
    const t = c.tasks.find((t2) => t2.id === cmd.taskId), decision = t?.actionId ? c.care?.decisions[t.actionId] : void 0;
    need(!decision || decision.state === "accepted", "\u0628\u06CC\u0645\u0627\u0631 \u0627\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645 \u0631\u0627 \u0631\u062F \u06CC\u0627 \u0628\u0647 \u0628\u0639\u062F \u0645\u0648\u06A9\u0648\u0644 \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A.");
  }
  if (cmd.kind === "care_cover_reply" && cmd.accept) {
    need(snapshot.cases.filter((x) => x.phone !== c.phone && effectiveDoctor(x) === a.phone && x.phase !== "draft").length < 20, "\u0638\u0631\u0641\u06CC\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u062C\u0627\u0646\u0634\u06CC\u0646 \u067E\u0631 \u0627\u0633\u062A\u061B \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0647\u0645\u0686\u0646\u0627\u0646 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0641\u0639\u0644\u06CC \u0645\u06CC\u200C\u0645\u0627\u0646\u062F.");
  }
  if (cmd.kind === "care_assign") {
    need(snapshot.cases.filter((x) => x.doctor === cmd.doctor && x.phase !== "draft").length < 20, "\u0638\u0631\u0641\u06CC\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u067E\u0632\u0634\u06A9 \u067E\u0631 \u0627\u0633\u062A.");
  }
  if (cmd.kind === "confirm" && cmd.accept) {
    const t = c.tasks.find((t2) => t2.id === cmd.taskId);
    if (t) need(!snapshot.cases.some((x) => x.phone !== c.phone && effectiveDoctor(x) === effectiveDoctor(c) && x.tasks.some((y) => y.kind === "visit" && y.status === "confirmed" && y.date === t.date && y.time === t.time)), "\u0627\u06CC\u0646 \u0632\u0645\u0627\u0646 \u0628\u0631\u0627\u06CC \u067E\u0632\u0634\u06A9 \u0631\u0632\u0631\u0648 \u0634\u062F\u0647 \u0627\u0633\u062A\u061B \u0632\u0645\u0627\u0646 \u062F\u06CC\u06AF\u0631\u06CC \u0628\u062E\u0648\u0627\u0647\u06CC\u062F.");
  }
  if (cmd.kind === "care_report") need(!snapshot.cases.some((x) => x.phone !== c.phone && x.care?.reports.some((r) => r.provider === clean(cmd.provider) && r.externalId === clean(cmd.externalId))), "\u0634\u0646\u0627\u0633\u0647\u0654 \u06AF\u0632\u0627\u0631\u0634 \u0642\u0628\u0644\u0627\u064B \u0628\u0631\u0627\u06CC \u067E\u0631\u0648\u0646\u062F\u0647\u0654 \u062F\u06CC\u06AF\u0631\u06CC \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F\u0647\u061B \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0628\u0631\u0631\u0633\u06CC \u062A\u0637\u0628\u06CC\u0642 \u062F\u0627\u0631\u062F.");
  if (cmd.kind === "care_delivery") need(a.role === "admin" || clinicalAccess(a, c), "\u0628\u0647 \u0648\u0636\u0639\u06CC\u062A \u062A\u062D\u0648\u06CC\u0644 \u062F\u0633\u062A\u0631\u0633\u06CC \u0646\u062F\u0627\u0631\u06CC\u062F.");
}
function memberProjection(c) {
  const out = structuredClone(c), j = care(out);
  j.membership.state = membershipState(out);
  const quarantine = new Set(j.reports.filter((r) => r.quarantined).map((r) => r.fileId));
  out.files = out.files.filter((f) => !quarantine.has(f.id)).map((f) => ({ ...f, reviewState: f.review ? "published" : j.reviews.some((r) => r.fileId === f.id && r.signedAt) ? "signed" : "pending" }));
  j.reports = j.reports.filter((r) => !r.quarantined);
  j.encounters = j.encounters.filter((e) => e.versions.length).map((e) => ({ ...e, draft: "", summary: e.versions.at(-1).summary, versions: e.versions.map((v) => ({ ...v, note: "" })) }));
  j.reviews = j.reviews.filter((r) => r.publishedAt).map((r) => ({ ...r, note: "" }));
  j.referrals = j.referrals.map((r) => ({ ...r, question: "", contacts: [] }));
  j.handovers = j.handovers.filter((h) => h.state === "accepted").map((h) => ({ ...h, reason: "" }));
  return out;
}

// next/seeds.ts
var preparedPeople = [
  { phone: "09000000003", name: "\u0646\u0631\u06AF\u0633 \u0634\u0631\u06CC\u0641\u06CC", hint: "\u06F1\u06F4 \u0645\u0627\u0647 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u0627\u0631\u062C\u0627\u0639 \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u06A9\u0627\u0645\u0644" },
  { phone: "09000000004", name: "\u0627\u0645\u06CC\u0631 \u0646\u06CC\u06A9\u200C\u0631\u0648\u0634", hint: "\u0628\u06CC\u0634 \u0627\u0632 \u06CC\u06A9 \u0633\u0627\u0644 \xB7 \u06AF\u0632\u0627\u0631\u0634 \u0627\u0635\u0644\u0627\u062D\u200C\u0634\u062F\u0647 \u0645\u0646\u062A\u0638\u0631 \u0628\u0631\u0631\u0633\u06CC" },
  { phone: "09000000005", name: "\u0645\u0631\u06CC\u0645 \u06A9\u06CC\u0627\u0646\u06CC", hint: "\u06CC\u06A9 \u0633\u0627\u0644 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u0646\u062A\u06CC\u062C\u0647 \u062A\u0648\u0636\u06CC\u062D \u062F\u0627\u062F\u0647 \u0634\u062F\u0647" },
  { phone: "09000000006", name: "\u0631\u0636\u0627 \u0627\u062D\u0645\u062F\u06CC", hint: "\u062F\u0648 \u0645\u0627\u0647 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u0632\u0645\u0627\u0646 \u0627\u0631\u062C\u0627\u0639 \u0645\u0646\u062A\u0638\u0631 \u062A\u0623\u06CC\u06CC\u062F" },
  { phone: "09000000007", name: "\u0644\u06CC\u0644\u0627 \u0645\u0648\u0633\u0648\u06CC", hint: "\u06F2\u06F5 \u0631\u0648\u0632 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0645\u0634\u06A9\u0644 \u0646\u0645\u0648\u0646\u0647" },
  { phone: "09000000008", name: "\u062D\u0645\u06CC\u062F \u0635\u0627\u062F\u0642\u06CC", hint: "\u06CC\u06A9 \u0647\u0641\u062A\u0647 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0648\u0644\u06CC\u0647" },
  { phone: "09000000009", name: "\u0647\u0627\u0646\u06CC\u0647 \u0631\u0636\u0627\u06CC\u06CC", hint: "\u062A\u0627\u0632\u0647 \u0648\u0627\u0631\u062F \xB7 \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0627\u0648\u0644\u06CC\u0646 \u0645\u0644\u0627\u0642\u0627\u062A" },
  { phone: "09000000010", name: "\u0639\u0644\u06CC \u0631\u0633\u062A\u06AF\u0627\u0631", hint: "\u0634\u0634 \u0645\u0627\u0647 \u0647\u0645\u0631\u0627\u0647\u06CC \xB7 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u062C\u0627\u0646\u0634\u06CC\u0646\u06CC \u067E\u0632\u0634\u06A9" }
];
function seedCareCases(base, transition2) {
  const cases = [...base], days = [420, 380, 365, 75, 25, 7, 2, 180], now = Date.now();
  for (let i = 0; i < preparedPeople.length; i++) {
    const p = preparedPeople[i];
    if (cases.some((c2) => c2.phone === p.phone)) continue;
    let c = structuredClone(base[1]);
    c.phone = p.phone;
    c.name = p.name;
    c.doctor = i % 2 ? "09000000014" : "09000000011";
    c.coordinator = i % 2 ? "09000000015" : "09000000012";
    c.version = 0;
    c.care = void 0;
    c.createdAt = now - days[i] * 864e5;
    c.submittedAt = c.createdAt + 864e5;
    c.files = [];
    c.messages = [];
    c.events = [];
    c.tasks = c.tasks.map((t, k) => ({ ...t, id: `seed-${i}-task-${k}`, owner: c.coordinator, ...t.planId ? { planId: `seed-${i}-plan`, actionId: `seed-${i}-action-1` } : {} }));
    c.plans = c.plans.map((plan) => ({ ...plan, id: `seed-${i}-plan`, doctor: c.doctor, createdAt: now - 12 * 864e5, actions: plan.actions.map((a, k) => ({ ...a, id: `seed-${i}-action-${k}`, done: i === 0 || i === 2 })) }));
    for (let month = 0; month < Math.max(1, Math.floor(days[i] / 30)); month++) c.events.push({ id: `seed-${i}-month-${month}`, at: c.createdAt + month * 30 * 864e5, title: month ? "\u0645\u0631\u0648\u0631 \u062F\u0648\u0631\u0647\u200C\u0627\u06CC \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0646\u0645\u0648\u0646\u0647" : "\u0634\u0631\u0648\u0639 \u0647\u0645\u0631\u0627\u0647\u06CC \u0648 \u062A\u0634\u06A9\u06CC\u0644 \u0633\u0627\u0628\u0642\u0647\u0654 \u0646\u0645\u0648\u0646\u0647", actor: "\u062A\u06CC\u0645 \u0646\u0645\u0648\u0646\u0647", kind: "doctor" });
    const actor = (phone, role) => ({ phone, id: phone, name: role === "member" ? c.name : role === "clinician" ? "\u067E\u0632\u0634\u06A9 \u0646\u0645\u0648\u0646\u0647" : "\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0646\u0645\u0648\u0646\u0647", role }), m = actor(c.phone, "member"), d = actor(c.doctor, "clinician"), co = actor(c.coordinator, "coordinator"), run = (cmd, a = d) => {
      c = transition2(c, a, cmd, c.version);
    }, due2 = localDay(new Date(now + (i === 7 ? -1 : 3) * 864e5));
    if (i === 5) {
      c.phase = "reviewing";
      c.plans = [];
      c.tasks = [];
      cases.push(c);
      continue;
    }
    if (i === 6) {
      c.phase = "awaiting_visit";
      c.plans = [];
      c.tasks = [{ id: "seed-first-visit", kind: "visit", title: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0622\u0634\u0646\u0627\u06CC\u06CC \u0628\u0627 \u067E\u0632\u0634\u06A9", why: "\u0622\u0634\u0646\u0627\u06CC\u06CC \u0648 \u0645\u0631\u0648\u0631 \u0627\u0648\u0644\u0648\u06CC\u062A\u200C\u0647\u0627\u06CC \u0628\u06CC\u0645\u0627\u0631", owner: c.coordinator, status: "requested", date: "", time: "", place: "", mode: "online", contactNote: "", outcome: "" }];
      cases.push(c);
      continue;
    }
    run({ kind: "care_history", medicines: "\u0641\u0647\u0631\u0633\u062A \u062F\u0627\u0631\u0648\u0647\u0627\u06CC \u0633\u0627\u062E\u062A\u06AF\u06CC \u0628\u0631\u0627\u06CC \u0645\u0631\u0648\u0631 \u062F\u0631 \u0645\u0644\u0627\u0642\u0627\u062A", allergies: "\u062F\u0631 \u0646\u0645\u0648\u0646\u0647\u060C \u0645\u0648\u0631\u062F \u0646\u0627\u0645\u0639\u0644\u0648\u0645 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0645\u0631\u0648\u0631 \u0634\u062F\u0647 \u0627\u0633\u062A.", other: "\u0627\u0648\u0644\u0648\u06CC\u062A: \u062F\u0627\u0634\u062A\u0646 \u0633\u0627\u0628\u0642\u0647\u0654 \u067E\u06CC\u0648\u0633\u062A\u0647 \u0648 \u0642\u062F\u0645 \u0628\u0639\u062F\u06CC \u0631\u0648\u0634\u0646." }, m);
    run({ kind: "care_verify_history" });
    run({ kind: "care_encounter", note: "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u0628\u0627\u0644\u06CC\u0646\u06CC \u0633\u0627\u062E\u062A\u06AF\u06CC\u060C \u0635\u0631\u0641\u0627\u064B \u0628\u0631\u0627\u06CC \u0646\u0645\u0627\u06CC\u0634 \u06AF\u0631\u062F\u0634 \u0645\u0644\u0627\u0642\u0627\u062A.", summary: "\u0633\u0627\u0628\u0642\u0647 \u0648 \u0627\u0648\u0644\u0648\u06CC\u062A\u200C\u0647\u0627 \u0645\u0631\u0648\u0631 \u0634\u062F\u061B \u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u0646\u0645\u0648\u0646\u0647 \u0648 \u0645\u0633\u0626\u0648\u0644 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0647\u0631 \u0642\u062F\u0645 \u0645\u0634\u062E\u0635 \u0627\u0633\u062A.", sign: true });
    run({ kind: "care_delivery", subject: "encounter:" + c.care.encounters.at(-1).id, outcome: "delivered" });
    run({ kind: "care_purchase", outcome: "success" }, m);
    run({ kind: "care_referral", type: i === 1 || i === 4 ? "lab" : "specialist", title: i === 1 || i === 4 ? "\u067E\u06CC\u06AF\u06CC\u0631\u06CC \u06AF\u0632\u0627\u0631\u0634 \u0622\u0632\u0645\u0627\u06CC\u0634 \u0646\u0645\u0648\u0646\u0647" : "\u0645\u0631\u0648\u0631 \u0646\u062A\u06CC\u062C\u0647 \u0628\u0627 \u0645\u062A\u062E\u0635\u0635 \u0646\u0645\u0648\u0646\u0647", question: "\u0633\u0624\u0627\u0644 \u0628\u0627\u0644\u06CC\u0646\u06CC \u0633\u0627\u062E\u062A\u06AF\u06CC \u0628\u0631\u0627\u06CC \u0646\u0634\u0627\u0646\u200C\u062F\u0627\u062F\u0646 \u0686\u0631\u062E\u0647\u0654 \u0627\u0631\u062C\u0627\u0639\u060C \u0628\u062F\u0648\u0646 \u062A\u0648\u0635\u06CC\u0647\u0654 \u067E\u0632\u0634\u06A9\u06CC.", dueAt: due2 });
    const rid = c.care.referrals[0].id;
    run({ kind: "care_referral_step", referralId: rid, step: "partner", partner: "\u0645\u0631\u06A9\u0632 \u0645\u0631\u0627\u0642\u0628\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u0622\u0628\u06CC", text: "\u0645\u0631\u06A9\u0632 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0645\u0634\u062E\u0635 \u0634\u062F." }, co);
    run({ kind: "care_authorize", referralId: rid, value: true }, m);
    for (const step of ["send", "accept", "book"]) run({ kind: "care_referral_step", referralId: rid, step, text: "\u0634\u0627\u0647\u062F \u0633\u0627\u062E\u062A\u06AF\u06CC \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0628\u0627 \u0645\u0631\u06A9\u0632 \u0646\u0645\u0648\u0646\u0647", partner: "\u0645\u0631\u06A9\u0632 \u0645\u0631\u0627\u0642\u0628\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u0622\u0628\u06CC", date: localDay(new Date(now + 5 * 864e5)), time: "11:00" }, co);
    if (i === 3) {
      cases.push(c);
      continue;
    }
    run({ kind: "care_confirm_referral", referralId: rid, accept: true }, m);
    run({ kind: "care_referral_step", referralId: rid, step: "attend", text: "\u0627\u0646\u062C\u0627\u0645 \u0645\u0631\u0627\u062C\u0639\u0647\u0654 \u0641\u0631\u0636\u06CC \u062B\u0628\u062A \u0634\u062F." }, co);
    if (i === 1 || i === 4) run({ kind: "care_referral_step", referralId: rid, step: i === 4 ? "reject_specimen" : "collect", text: i === 4 ? "\u062F\u0631 \u0633\u0646\u0627\u0631\u06CC\u0648\u06CC \u0633\u0627\u062E\u062A\u06AF\u06CC\u060C \u0646\u06CC\u0627\u0632 \u0628\u0647 \u062A\u06A9\u0631\u0627\u0631 \u0646\u0645\u0648\u0646\u0647 \u0628\u0627 \u0645\u0631\u06A9\u0632 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0645\u06CC\u200C\u0634\u0648\u062F." : "\u062F\u0631\u06CC\u0627\u0641\u062A \u0646\u0645\u0648\u0646\u0647\u0654 \u0641\u0631\u0636\u06CC \u062B\u0628\u062A \u0634\u062F." }, co);
    if (i === 4) {
      cases.push(c);
      continue;
    }
    const receive = (suffix, supersedes) => {
      const fid2 = `seed-report-${i}-${suffix}`;
      run({ kind: "care_report", referralId: rid, file: { id: fid2, name: `\u06AF\u0632\u0627\u0631\u0634 ${c.name} \u2014 ${suffix === "v1" ? "\u0646\u0633\u062E\u0647 \u0627\u0648\u0644" : "\u0627\u0635\u0644\u0627\u062D\u200C\u0634\u062F\u0647"} \u2014 \u0633\u0627\u062E\u062A\u06AF\u06CC.pdf`, mime: "application/pdf", bytes: 20, createdAt: now, source: "coordinator", blob: new Blob(["%PDF-1.7\nSYNTHETIC\n%%EOF"], { type: "application/pdf" }) }, provider: "\u0645\u0631\u06A9\u0632 \u0633\u0627\u062E\u062A\u06AF\u06CC \u0622\u0628\u06CC", externalId: `seed-event-${i}-${suffix}`, supersedes, uncertain: false }, co);
      const f = c.files.find((f2) => f2.id === fid2);
      delete f.blob;
      f.source = "fixture";
      f.fixture = `./demo/documents/case-${i + 3}-${suffix}.pdf`;
      const metadata = manifest_default.files[`case-${i + 3}-${suffix}.pdf`];
      f.bytes = metadata.bytes;
      f.checksum = metadata.sha256;
      c.care.reports.find((m2) => m2.fileId === fid2).checksum = metadata.sha256;
      return fid2;
    };
    const fid = receive("v1");
    run({ kind: "care_review", fileId: fid, note: "\u0628\u0631\u0631\u0633\u06CC \u0628\u0627\u0644\u06CC\u0646\u06CC \u0641\u0631\u0636\u06CC \u0627\u06CC\u0646 \u0646\u0633\u062E\u0647 \u062B\u0628\u062A \u0634\u062F\u061B \u0647\u06CC\u0686 \u0646\u062A\u06CC\u062C\u0647\u0654 \u0648\u0627\u0642\u0639\u06CC \u0627\u0633\u062A\u0646\u062A\u0627\u062C \u0646\u0645\u06CC\u200C\u0634\u0648\u062F.", explanation: "\u06AF\u0632\u0627\u0631\u0634 \u0646\u0645\u0648\u0646\u0647 \u0628\u0627 \u0633\u0627\u0628\u0642\u0647 \u0645\u0631\u0648\u0631 \u0634\u062F. \u062A\u0648\u0636\u06CC\u062D \u0648 \u0642\u062F\u0645 \u0628\u0639\u062F \u062F\u0631 \u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u0634\u0645\u0627 \u0642\u0627\u0628\u0644 \u0645\u0634\u0627\u0647\u062F\u0647 \u0627\u0633\u062A.", followup: "", dueAt: due2, sign: true });
    run({ kind: "care_publish_review", fileId: fid });
    run({ kind: "care_delivery", subject: "report:" + fid, outcome: "delivered" });
    run({ kind: "care_ack", fileId: fid }, m);
    if (i === 1) receive("v2", fid);
    else if (i === 7) run({ kind: "care_cover", to: c.doctor === "09000000014" ? "09000000011" : "09000000014", until: localDay(new Date(now + 10 * 864e5)), reason: "\u067E\u06CC\u0634\u0646\u0647\u0627\u062F \u062C\u0627\u0646\u0634\u06CC\u0646\u06CC \u0646\u0645\u0648\u0646\u0647\u061B \u062A\u0627 \u067E\u0630\u06CC\u0631\u0634\u060C \u0645\u0633\u0626\u0648\u0644\u06CC\u062A \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0642\u0628\u0644\u06CC \u0627\u0633\u062A." });
    else run({ kind: "care_referral_step", referralId: rid, step: "close", text: "\u0645\u0631\u0648\u0631\u060C \u062A\u0648\u0636\u06CC\u062D \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0627\u0631\u062C\u0627\u0639 \u0641\u0631\u0636\u06CC \u06A9\u0627\u0645\u0644 \u0634\u062F." });
    cases.push(c);
  }
  return cases;
}

// next/model.ts
var staff = [{ phone: "09000000011", name: "\u067E\u0632\u0634\u06A9 \u0627\u0648\u0644", role: "clinician" }, { phone: "09000000014", name: "\u067E\u0632\u0634\u06A9 \u062F\u0648\u0645", role: "clinician" }, { phone: "09000000012", name: "\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0627\u0648\u0644", role: "coordinator" }, { phone: "09000000015", name: "\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u062F\u0648\u0645", role: "coordinator" }, { phone: "09000000013", name: "\u0645\u062F\u06CC\u0631 \u0646\u0645\u0648\u0646\u0647", role: "admin" }];
var demoPeople = [{ phone: "09000000001", name: "\u0634\u0631\u0648\u0639 \u062A\u0627\u0632\u0647", hint: "\u0627\u0632 \u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647 \u062A\u0627 \u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u067E\u0632\u0634\u06A9", role: "member" }, { phone: "09000000002", name: "\u0633\u0627\u0631\u0627 \u0631\u0627\u062F", hint: "\u067E\u0631\u0648\u0646\u062F\u0647\u0654 \u0622\u0645\u0627\u062F\u0647 \u0628\u0627 \u0628\u0631\u0646\u0627\u0645\u0647 \u0648 \u06AF\u0632\u0627\u0631\u0634", role: "member" }, ...preparedPeople.map((x) => ({ ...x, role: "member" })), ...staff.map((x) => ({ ...x, hint: x.role === "clinician" ? "\u0628\u0631\u0631\u0633\u06CC \u067E\u0631\u0648\u0646\u062F\u0647 \u0648 \u062A\u0648\u0636\u06CC\u062D \u0646\u062A\u06CC\u062C\u0647" : x.role === "coordinator" ? "\u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0648 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u06AF\u0632\u0627\u0631\u0634" : "\u0638\u0631\u0641\u06CC\u062A \u0648 \u0648\u0636\u0639\u06CC\u062A \u062E\u062F\u0645\u062A" }))];
var options = (pairs) => pairs.map(([value, label, hint]) => ({ value, label, hint }));
var questions = [
  { id: "goal", title: "\u0627\u0632 \u0627\u06CC\u0646 \u0647\u0645\u0631\u0627\u0647\u06CC \u0686\u0647 \u0645\u06CC\u200C\u062E\u0648\u0627\u0647\u06CC\u062F\u061F", help: "\u0627\u0632 \u0686\u06CC\u0632\u06CC \u0634\u0631\u0648\u0639 \u06A9\u0646\u06CC\u0645 \u06A9\u0647 \u0628\u0631\u0627\u06CC \u062E\u0648\u062F\u062A\u0627\u0646 \u0645\u0647\u0645\u200C\u062A\u0631 \u0627\u0633\u062A.", icon: "heart", options: options([["understand", "\u0633\u0644\u0627\u0645\u062A\u0645 \u0631\u0627 \u0628\u0647\u062A\u0631 \u0628\u0634\u0646\u0627\u0633\u0645", "\u0628\u062F\u0627\u0646\u0645 \u0627\u0632 \u06A9\u062C\u0627 \u0634\u0631\u0648\u0639 \u06A9\u0646\u0645."], ["continuity", "\u067E\u0632\u0634\u06A9\u06CC \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u0645 \u06A9\u0647 \u0645\u0646 \u0631\u0627 \u0628\u0634\u0646\u0627\u0633\u062F", "\u0628\u0631\u0627\u06CC \u067E\u06CC\u06AF\u06CC\u0631\u06CC\u200C\u0647\u0627\u06CC \u0628\u0639\u062F\u06CC\u060C \u0627\u0632 \u0646\u0648 \u0634\u0631\u0648\u0639 \u0646\u06A9\u0646\u0645."], ["records", "\u0633\u0627\u0628\u0642\u0647 \u0648 \u0645\u062F\u0627\u0631\u06A9\u0645 \u0631\u0627 \u0645\u0631\u062A\u0628 \u06A9\u0646\u0645", "\u0627\u0637\u0644\u0627\u0639\u0627\u062A\u0645 \u06A9\u0646\u0627\u0631 \u0647\u0645 \u0628\u0627\u0634\u062F."]]) },
  { id: "age", title: "\u062F\u0631 \u06A9\u062F\u0627\u0645 \u06AF\u0631\u0648\u0647 \u0633\u0646\u06CC \u0647\u0633\u062A\u06CC\u062F\u061F", help: "\u0628\u0631\u0627\u06CC \u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647\u060C \u0647\u0645\u06CC\u0646 \u0628\u0627\u0632\u0647 \u06A9\u0627\u0641\u06CC \u0627\u0633\u062A.", icon: "user", options: options([["18-29", "\u06F1\u06F8 \u062A\u0627 \u06F2\u06F9 \u0633\u0627\u0644"], ["30-44", "\u06F3\u06F0 \u062A\u0627 \u06F4\u06F4 \u0633\u0627\u0644"], ["45-59", "\u06F4\u06F5 \u062A\u0627 \u06F5\u06F9 \u0633\u0627\u0644"], ["60+", "\u06F6\u06F0 \u0633\u0627\u0644 \u0648 \u0628\u06CC\u0634\u062A\u0631"]]) },
  { id: "city", title: "\u062F\u0631 \u06A9\u062F\u0627\u0645 \u0634\u0647\u0631 \u0632\u0646\u062F\u06AF\u06CC \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F\u061F", help: "\u0628\u0631\u0627\u06CC \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC\u200C\u0647\u0627\u06CC \u0627\u062D\u062A\u0645\u0627\u0644\u06CC\u061B \u0627\u0646\u062A\u062E\u0627\u0628 \u0634\u0647\u0631 \u0628\u0647 \u0645\u0639\u0646\u06CC \u0641\u0639\u0627\u0644\u200C\u0628\u0648\u062F\u0646 \u062E\u062F\u0645\u062A \u0648\u0627\u0642\u0639\u06CC \u062F\u0631 \u0622\u0646 \u0646\u06CC\u0633\u062A.", icon: "home", type: "city" },
  { id: "conditions", title: "\u0628\u06CC\u0645\u0627\u0631\u06CC \u0634\u0646\u0627\u062E\u062A\u0647\u200C\u0634\u062F\u0647\u200C\u0627\u06CC \u062F\u0627\u0631\u06CC\u062F\u061F", help: "\u0641\u0642\u0637 \u0645\u0648\u0631\u062F\u06CC \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F \u06A9\u0647 \u0642\u0628\u0644\u0627\u064B \u062F\u0631\u0628\u0627\u0631\u0647\u200C\u0627\u0634 \u0645\u0637\u0644\u0639 \u0634\u062F\u0647\u200C\u0627\u06CC\u062F. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u0686\u0646\u062F \u0645\u0648\u0631\u062F \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.", icon: "file", type: "multi", options: options([["diabetes", "\u062F\u06CC\u0627\u0628\u062A"], ["pressure", "\u0641\u0634\u0627\u0631 \u062E\u0648\u0646 \u0628\u0627\u0644\u0627"], ["lipids", "\u0686\u0631\u0628\u06CC \u062E\u0648\u0646"], ["thyroid", "\u0645\u0634\u06A9\u0644 \u062A\u06CC\u0631\u0648\u0626\u06CC\u062F"], ["other", "\u0645\u0648\u0631\u062F \u062F\u06CC\u06AF\u0631\u06CC \u062F\u0627\u0631\u0645"], ["none", "\u0645\u0648\u0631\u062F\u06CC \u0633\u0631\u0627\u063A \u0646\u062F\u0627\u0631\u0645"], ["unknown", "\u0645\u0637\u0645\u0626\u0646 \u0646\u06CC\u0633\u062A\u0645"]]) },
  { id: "medicines", title: "\u062F\u0627\u0631\u0648\u06CC \u0645\u0646\u0638\u0645\u06CC \u0645\u0635\u0631\u0641 \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F\u061F", help: "\u0646\u0627\u0645 \u0648 \u062C\u0632\u0626\u06CC\u0627\u062A \u062F\u0627\u0631\u0648 \u0631\u0627 \u0628\u0639\u062F\u0627\u064B \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0645\u0631\u0648\u0631 \u0645\u06CC\u200C\u06A9\u0646\u06CC\u062F.", icon: "shield", options: options([["yes", "\u0628\u0644\u0647"], ["no", "\u062E\u06CC\u0631"], ["unknown", "\u0645\u0637\u0645\u0626\u0646 \u0646\u06CC\u0633\u062A\u0645"]]) },
  { id: "allergies", title: "\u062D\u0633\u0627\u0633\u06CC\u062A \u062F\u0627\u0631\u0648\u06CC\u06CC \u0634\u0646\u0627\u062E\u062A\u0647\u200C\u0634\u062F\u0647 \u062F\u0627\u0631\u06CC\u062F\u061F", help: "\u062C\u0632\u0626\u06CC\u0627\u062A \u0648 \u0627\u0647\u0645\u06CC\u062A \u0622\u0646 \u0631\u0627 \u067E\u0632\u0634\u06A9 \u0628\u0631\u0631\u0633\u06CC \u0645\u06CC\u200C\u06A9\u0646\u062F.", icon: "shield", options: options([["yes", "\u0628\u0644\u0647"], ["no", "\u0645\u0648\u0631\u062F\u06CC \u0633\u0631\u0627\u063A \u0646\u062F\u0627\u0631\u0645"], ["unknown", "\u0646\u0645\u06CC\u200C\u062F\u0627\u0646\u0645"]]) },
  { id: "height", title: "\u0642\u062F\u062A\u0627\u0646 \u062D\u062F\u0648\u062F\u0627\u064B \u0686\u0642\u062F\u0631 \u0627\u0633\u062A\u061F", help: "\u0627\u06AF\u0631 \u0628\u0647 \u062E\u0627\u0637\u0631 \u0646\u062F\u0627\u0631\u06CC\u062F\u060C \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u0627\u0632 \u0627\u06CC\u0646 \u0633\u0624\u0627\u0644 \u0628\u06AF\u0630\u0631\u06CC\u062F.", icon: "chart", type: "number", unit: "\u0633\u0627\u0646\u062A\u06CC\u200C\u0645\u062A\u0631", min: 80, max: 250 },
  { id: "weight", title: "\u0648\u0632\u0646\u062A\u0627\u0646 \u062D\u062F\u0648\u062F\u0627\u064B \u0686\u0642\u062F\u0631 \u0627\u0633\u062A\u061F", help: "\u0628\u0631\u0627\u06CC \u0634\u0646\u0627\u062E\u062A \u0627\u0648\u0644\u06CC\u0647\u061B \u0627\u06CC\u0646 \u0639\u062F\u062F \u0628\u0647\u200C\u062A\u0646\u0647\u0627\u06CC\u06CC \u0627\u0631\u0632\u06CC\u0627\u0628\u06CC \u0633\u0644\u0627\u0645\u062A \u0646\u06CC\u0633\u062A.", icon: "chart", type: "number", unit: "\u06A9\u06CC\u0644\u0648\u06AF\u0631\u0645", min: 20, max: 400 },
  { id: "review", title: "\u0622\u062E\u0631\u06CC\u0646 \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9\u06CC\u200C\u062A\u0627\u0646 \u0686\u0647 \u0632\u0645\u0627\u0646\u06CC \u0628\u0648\u062F\u061F", help: "\u062A\u0642\u0631\u06CC\u0628\u06CC \u067E\u0627\u0633\u062E \u0628\u062F\u0647\u06CC\u062F\u061B \u062F\u0627\u0634\u062A\u0646 \u0622\u0632\u0645\u0627\u06CC\u0634 \u0642\u0628\u0644\u06CC \u0644\u0627\u0632\u0645 \u0646\u06CC\u0633\u062A.", icon: "calendar", options: options([["recent", "\u062F\u0631 \u0634\u0634 \u0645\u0627\u0647 \u06AF\u0630\u0634\u062A\u0647"], ["year", "\u0634\u0634 \u0645\u0627\u0647 \u062A\u0627 \u06CC\u06A9 \u0633\u0627\u0644 \u067E\u06CC\u0634"], ["older", "\u0628\u06CC\u0634 \u0627\u0632 \u06CC\u06A9 \u0633\u0627\u0644 \u067E\u06CC\u0634"], ["unknown", "\u06CC\u0627\u062F\u0645 \u0646\u06CC\u0633\u062A / \u0628\u0631\u0631\u0633\u06CC \u0646\u062F\u0627\u0634\u062A\u0647\u200C\u0627\u0645"]]) },
  { id: "sleep", title: "\u0627\u06CC\u0646 \u0631\u0648\u0632\u0647\u0627 \u062E\u0648\u0627\u0628\u062A\u0627\u0646 \u0686\u0637\u0648\u0631 \u0627\u0633\u062A\u061F", help: "\u067E\u0627\u0633\u062E \u0634\u0645\u0627 \u0634\u0631\u0648\u0639 \u06CC\u06A9 \u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u0633\u062A\u060C \u0646\u0647 \u0646\u062A\u06CC\u062C\u0647\u0654 \u062A\u0634\u062E\u06CC\u0635.", icon: "sun", options: options([["rested", "\u0645\u0639\u0645\u0648\u0644\u0627\u064B \u0628\u0627 \u0627\u0633\u062A\u0631\u0627\u062D\u062A \u06A9\u0627\u0641\u06CC \u0628\u06CC\u062F\u0627\u0631 \u0645\u06CC\u200C\u0634\u0648\u0645"], ["variable", "\u0628\u0639\u0636\u06CC \u0631\u0648\u0632\u0647\u0627 \u062E\u0648\u0628\u060C \u0628\u0639\u0636\u06CC \u0631\u0648\u0632\u0647\u0627 \u0646\u0647"], ["tired", "\u0628\u06CC\u0634\u062A\u0631 \u0631\u0648\u0632\u0647\u0627 \u0627\u062D\u0633\u0627\u0633 \u062E\u0633\u062A\u06AF\u06CC \u062F\u0627\u0631\u0645"], ["skip", "\u062A\u0631\u062C\u06CC\u062D \u0645\u06CC\u200C\u062F\u0647\u0645 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0635\u062D\u0628\u062A \u06A9\u0646\u0645"]]) },
  { id: "movement", title: "\u062A\u062D\u0631\u06A9 \u062F\u0631 \u0631\u0648\u0632\u0647\u0627\u06CC\u062A\u0627\u0646 \u0686\u0647 \u062C\u0627\u06CC\u06CC \u062F\u0627\u0631\u062F\u061F", help: "\u0641\u0639\u0627\u0644\u06CC\u062A \u0631\u0648\u0632\u0645\u0631\u0647\u060C \u067E\u06CC\u0627\u062F\u0647\u200C\u0631\u0648\u06CC \u06CC\u0627 \u0648\u0631\u0632\u0634 \u0631\u0627 \u062F\u0631 \u0646\u0638\u0631 \u0628\u06AF\u06CC\u0631\u06CC\u062F.", icon: "route", options: options([["regular", "\u0628\u06CC\u0634\u062A\u0631 \u0631\u0648\u0632\u0647\u0627 \u0641\u0639\u0627\u0644\u06CC\u062A \u062F\u0627\u0631\u0645"], ["sometimes", "\u0628\u0639\u0636\u06CC \u0631\u0648\u0632\u0647\u0627 \u0641\u0639\u0627\u0644\u06CC\u062A \u062F\u0627\u0631\u0645"], ["little", "\u0645\u0639\u0645\u0648\u0644\u0627\u064B \u06A9\u0645\u200C\u062A\u062D\u0631\u06A9\u0645"], ["skip", "\u0628\u0639\u062F\u0627\u064B \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0645\u0631\u0648\u0631 \u0645\u06CC\u200C\u06A9\u0646\u0645"]]) },
  { id: "visit", title: "\u0628\u0631\u0627\u06CC \u0622\u0634\u0646\u0627\u06CC\u06CC \u0628\u0627 \u067E\u0632\u0634\u06A9 \u06A9\u062F\u0627\u0645 \u0631\u0627 \u062A\u0631\u062C\u06CC\u062D \u0645\u06CC\u200C\u062F\u0647\u06CC\u062F\u061F", help: "\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0628\u0631\u0627\u06CC \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0628\u0627 \u0634\u0645\u0627 \u062A\u0645\u0627\u0633 \u0645\u06CC\u200C\u06AF\u06CC\u0631\u062F. \u0627\u06CC\u0646 \u0627\u0646\u062A\u062E\u0627\u0628 \u0647\u0646\u0648\u0632 \u0646\u0648\u0628\u062A \u0642\u0637\u0639\u06CC \u0646\u06CC\u0633\u062A.", icon: "doctor", options: options([["online", "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0622\u0646\u0644\u0627\u06CC\u0646"], ["phone", "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u062A\u0644\u0641\u0646\u06CC"], ["in_person", "\u0645\u0644\u0627\u0642\u0627\u062A \u062D\u0636\u0648\u0631\u06CC"], ["discuss", "\u0628\u0627 \u06A9\u0645\u06A9 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0627\u0646\u062A\u062E\u0627\u0628 \u0645\u06CC\u200C\u06A9\u0646\u0645"]]) }
];
function emptyCase(phone, name, secondary = false) {
  return { phone, name, doctor: secondary ? "09000000014" : "09000000011", coordinator: secondary ? "09000000015" : "09000000012", phase: "draft", version: 0, consent: false, contactConsent: false, answers: {}, step: 0, createdAt: Date.now(), clarification: "", clarificationReply: "", urgent: false, urgentReason: "", urgentNote: "", plans: [], tasks: [], files: [], events: [], messages: [] };
}
function initialSnapshot() {
  const fresh = emptyCase("09000000001", "\u0634\u0645\u0627"), sara = emptyCase("09000000002", "\u0633\u0627\u0631\u0627 \u0631\u0627\u062F", true), now = Date.now();
  sara.phase = "active";
  sara.consent = true;
  sara.contactConsent = true;
  sara.createdAt = now - 240 * 864e5;
  sara.submittedAt = now - 235 * 864e5;
  sara.answers = { goal: "continuity", age: "30-44", city: "\u062A\u0647\u0631\u0627\u0646", conditions: ["none"], medicines: "no", allergies: "unknown", height: "165", weight: "65", review: "recent", sleep: "variable", movement: "sometimes", visit: "online" };
  sara.step = questions.length;
  sara.plans = [{ id: "sara-plan-1", summary: "\u062F\u0631 \u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0646\u0645\u0648\u0646\u0647\u060C \u0633\u0627\u0628\u0642\u0647\u0654 \u0633\u0644\u0627\u0645\u062A \u0648 \u0627\u0648\u0644\u0648\u06CC\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0645\u0631\u0648\u0631 \u0634\u062F. \u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0628\u0627 \u062A\u0648\u062C\u0647 \u0628\u0647 \u067E\u0631\u0633\u0634\u200C\u0647\u0627\u06CC \u062E\u0648\u062F\u062A\u0627\u0646 \u062A\u0646\u0638\u06CC\u0645 \u0634\u062F\u0647 \u0627\u0633\u062A. \u062A\u0648\u0636\u06CC\u062D \u062A\u0627\u0632\u0647\u0654 \u06AF\u0632\u0627\u0631\u0634 \u067E\u0633 \u0627\u0632 \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u062F\u0631 \u0647\u0645\u06CC\u0646\u200C\u062C\u0627 \u0627\u0636\u0627\u0641\u0647 \u0645\u06CC\u200C\u0634\u0648\u062F.", createdAt: now - 7 * 864e5, doctor: sara.doctor, actions: [{ id: "sara-personal", title: "\u067E\u0631\u0633\u0634\u200C\u0647\u0627\u06CC\u062A\u0627\u0646 \u0631\u0627 \u0628\u0631\u0627\u06CC \u0645\u0631\u0648\u0631 \u0628\u0639\u062F\u06CC \u0622\u0645\u0627\u062F\u0647 \u06A9\u0646\u06CC\u062F", why: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648 \u0627\u0632 \u0627\u0648\u0644\u0648\u06CC\u062A\u200C\u0647\u0627\u06CC \u062E\u0648\u062F\u062A\u0627\u0646 \u0634\u0631\u0648\u0639 \u0634\u0648\u062F.", owner: "member", due: "\u062F\u0631 \u0645\u0631\u0648\u0631 \u0628\u0639\u062F\u06CC", done: false }, { id: "sara-report", title: "\u06AF\u0632\u0627\u0631\u0634 \u0642\u0628\u0644\u06CC \u0628\u0631\u0627\u06CC \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0634\u0648\u062F", why: "\u0645\u0646\u0628\u0639 \u0648 \u062C\u0632\u0626\u06CC\u0627\u062A \u06AF\u0632\u0627\u0631\u0634 \u06A9\u0646\u0627\u0631 \u0633\u0627\u0628\u0642\u0647 \u0628\u0627\u0634\u062F.", owner: "team", due: "\u062F\u0631 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u062C\u0627\u0631\u06CC", done: true }] }];
  sara.tasks = [{ id: "sara-visit", kind: "visit", title: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0622\u0634\u0646\u0627\u06CC\u06CC \u0628\u0627 \u067E\u0632\u0634\u06A9", why: "\u0645\u0631\u0648\u0631 \u0633\u0627\u0628\u0642\u0647 \u0648 \u0627\u0648\u0644\u0648\u06CC\u062A\u200C\u0647\u0627", owner: sara.coordinator, status: "completed", date: "\u0646\u0645\u0648\u0646\u0647\u0654 \u062B\u0628\u062A\u200C\u0634\u062F\u0647", time: "\u06F1\u06F0:\u06F0\u06F0", place: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0622\u0646\u0644\u0627\u06CC\u0646 \u0646\u0645\u0648\u0646\u0647", mode: "online", contactNote: "\u0632\u0645\u0627\u0646 \u0628\u0627 \u0639\u0636\u0648 \u0647\u0645\u0627\u0647\u0646\u06AF \u0634\u062F.", outcome: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0646\u0645\u0648\u0646\u0647 \u0627\u0646\u062C\u0627\u0645 \u0648 \u0628\u0631\u0646\u0627\u0645\u0647 \u062B\u0628\u062A \u0634\u062F." }, { id: "sara-lab", kind: "service", title: "\u062F\u0631\u06CC\u0627\u0641\u062A \u06AF\u0632\u0627\u0631\u0634 \u0642\u0628\u0644\u06CC", why: "\u0628\u0631\u0627\u06CC \u0645\u0631\u0648\u0631 \u062A\u0648\u0633\u0637 \u067E\u0632\u0634\u06A9", owner: sara.coordinator, status: "completed", date: "\u0646\u0645\u0648\u0646\u0647\u0654 \u062B\u0628\u062A\u200C\u0634\u062F\u0647", time: "\u06F1\u06F1:\u06F0\u06F0", place: "\u0645\u0631\u06A9\u0632 \u0641\u0631\u0636\u06CC \u0622\u0628\u06CC", mode: "in_person", contactNote: "\u06AF\u0632\u0627\u0631\u0634 \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F.", outcome: "\u0627\u0635\u0644 \u06AF\u0632\u0627\u0631\u0634 \u0646\u0645\u0648\u0646\u0647 \u062F\u0631 \u067E\u0631\u0648\u0646\u062F\u0647 \u0642\u0631\u0627\u0631 \u06AF\u0631\u0641\u062A.", planId: "sara-plan-1", actionId: "sara-report" }];
  sara.files = [{ id: "sara-file", name: "\u06AF\u0632\u0627\u0631\u0634 \u0622\u0632\u0645\u0627\u06CC\u0634 \u0633\u0627\u0631\u0627 \u2014 \u0633\u0627\u062E\u062A\u06AF\u06CC.pdf", mime: "application/pdf", bytes: manifest_default.files["51-lab.pdf"].bytes, checksum: manifest_default.files["51-lab.pdf"].sha256, createdAt: now - 864e5, source: "fixture", taskId: "sara-lab", fixture: "./demo/documents/51-lab.pdf" }];
  sara.events = [{ id: "sara-start", at: now - 240 * 864e5, title: "\u0634\u0631\u0648\u0639 \u0647\u0645\u0631\u0627\u0647\u06CC \u0648 \u062A\u0634\u06A9\u06CC\u0644 \u0633\u0627\u0628\u0642\u0647\u0654 \u0627\u0648\u0644\u06CC\u0647", actor: "\u0639\u0636\u0648", kind: "member" }, { id: "sara-met", at: now - 8 * 864e5, title: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0645\u0631\u0648\u0631 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0627\u0646\u062C\u0627\u0645 \u0634\u062F", actor: "\u067E\u0632\u0634\u06A9 \u062F\u0648\u0645", kind: "doctor" }, { id: "sara-plan", at: now - 7 * 864e5, title: "\u0628\u0631\u0646\u0627\u0645\u0647\u0654 \u062A\u0627\u0632\u0647 \u0645\u0646\u062A\u0634\u0631 \u0634\u062F", actor: "\u067E\u0632\u0634\u06A9 \u062F\u0648\u0645", kind: "doctor" }, { id: "sara-received", at: now - 864e5, title: "\u06AF\u0632\u0627\u0631\u0634 \u062F\u0631\u06CC\u0627\u0641\u062A \u0648 \u0628\u0631\u0627\u06CC \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u062B\u0628\u062A \u0634\u062F", actor: "\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u062F\u0648\u0645", kind: "team" }];
  return { schema: 1, cases: seedCareCases([fresh, sara], transition) };
}
function need2(condition, message) {
  if (!condition) throw new Error(message);
}
var text = (s) => s.trim().slice(0, 4e3);
function allowed(actor, c) {
  return actor.role === "member" ? actor.phone === c.phone : actor.role === "clinician" ? clinicalAccess(actor, c) : actor.role === "coordinator" ? !!coordinationAccess(actor, c) : false;
}
function transition(original, actor, command, expected) {
  const payload = command;
  need2(payload && typeof payload === "object" && !Array.isArray(payload) && typeof payload.kind === "string", "\u0641\u0631\u0645\u0627\u0646 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  for (const key of ["consent", "contactConsent", "value", "accept", "done", "sign", "uncertain", "escalate"]) if (key in payload) need2(typeof payload[key] === "boolean", "\u06AF\u0632\u06CC\u0646\u0647\u0654 \u0628\u0644\u0647 \u06CC\u0627 \u062E\u06CC\u0631 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  for (const key of ["id", "taskId", "actionId", "fileId", "referralId", "doctor", "to", "until", "reason", "text", "title", "question", "dueAt", "date", "time", "place", "mode", "note", "summary", "explanation", "followup", "medicines", "allergies", "other", "type", "partner", "provider", "externalId", "supersedes", "outcome", "decision", "subject"]) if (payload[key] !== void 0) need2(typeof payload[key] === "string", "\u0645\u062A\u0646 \u0641\u0631\u0645\u0627\u0646 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  if ((original.organizationId || "salamatban-demo") !== (actor.organizationId || "salamatban-demo")) throw Error("\u0628\u0647 \u0627\u06CC\u0646 \u0633\u0627\u0632\u0645\u0627\u0646 \u062F\u0633\u062A\u0631\u0633\u06CC \u0646\u062F\u0627\u0631\u06CC\u062F.");
  if (command.kind.startsWith("care_")) return careTransition(original, actor, command, expected);
  need2(original.version === expected, "\u067E\u0631\u0648\u0646\u062F\u0647 \u062F\u0631 \u067E\u0646\u062C\u0631\u0647\u0654 \u062F\u06CC\u06AF\u0631\u06CC \u062A\u063A\u06CC\u06CC\u0631 \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A\u061B \u062A\u0627\u0632\u0647\u200C\u0633\u0627\u0632\u06CC \u06A9\u0646\u06CC\u062F.");
  const member = actor.role === "member" && actor.phone === original.phone, doctor = actor.role === "clinician" && actor.phone === effectiveDoctor(original) && (original.phase !== "draft" || original.urgent), coordinator = actor.role === "coordinator";
  need2(member || doctor || coordinator && original.tasks.some((t) => t.owner === actor.phone), "\u0628\u0647 \u0627\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645 \u062F\u0633\u062A\u0631\u0633\u06CC \u0646\u062F\u0627\u0631\u06CC\u062F.");
  const c = structuredClone(original), event = (title) => c.events.push({ id: crypto.randomUUID(), at: Date.now(), title, actor: actor.role === "member" ? "\u0639\u0636\u0648" : staff.find((x) => x.phone === actor.phone)?.name || actor.name, kind: member ? "member" : doctor ? "doctor" : "team" });
  const task = (id2) => {
    const t = c.tasks.find((x) => x.id === id2);
    need2(t, "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    return t;
  };
  const ownTask = (id2) => {
    const t = task(id2);
    need2(coordinator && t.owner === actor.phone, "\u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0647 \u0634\u0645\u0627 \u062A\u062E\u0635\u06CC\u0635 \u0646\u062F\u0627\u0631\u062F.");
    return t;
  };
  const doctorStep = () => {
    need2(doctor, "\u0627\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u0633\u062A.");
    need2(!c.urgent, "\u0627\u0628\u062A\u062F\u0627 \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631 \u0631\u0627 \u0628\u0631\u0631\u0633\u06CC \u0648 \u0646\u062A\u06CC\u062C\u0647\u0654 \u0631\u0633\u06CC\u062F\u06AF\u06CC \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
  };
  switch (command.kind) {
    case "save":
      need2(member && c.phase === "draft", "\u0641\u0631\u0645 \u0627\u0648\u0644\u06CC\u0647 \u062F\u0631 \u0627\u06CC\u0646 \u0648\u0636\u0639\u06CC\u062A \u0642\u0627\u0628\u0644 \u0648\u06CC\u0631\u0627\u06CC\u0634 \u0646\u06CC\u0633\u062A.");
      {
        const clean2 = {};
        for (const q of questions) {
          const v = command.answers[q.id];
          if (v === void 0) continue;
          if (q.options) {
            if (q.type === "multi") {
              need2(Array.isArray(v) && v.length > 0 && v.every((x) => q.options.some((o) => o.value === x)), "\u067E\u0627\u0633\u062E \u0645\u0639\u062A\u0628\u0631 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
              need2(!(v.some((x) => x === "none" || x === "unknown") && v.length > 1), "\u06AF\u0632\u06CC\u0646\u0647\u0654 \xAB\u0647\u06CC\u0686 \u0645\u0648\u0631\u062F\xBB \u06CC\u0627 \xAB\u0645\u0637\u0645\u0626\u0646 \u0646\u06CC\u0633\u062A\u0645\xBB \u062C\u062F\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u0645\u06CC\u200C\u0634\u0648\u062F.");
              clean2[q.id] = [...new Set(v)];
            } else {
              need2(typeof v === "string" && q.options.some((o) => o.value === v), "\u067E\u0627\u0633\u062E \u0645\u0639\u062A\u0628\u0631 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
              clean2[q.id] = v;
            }
          } else {
            need2(typeof v === "string", "\u067E\u0627\u0633\u062E \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
            if (q.type === "number" && v !== "skip") need2(Number(v) >= q.min && Number(v) <= q.max, "\u0639\u062F\u062F \u0631\u0627 \u062F\u0631 \u0645\u062D\u062F\u0648\u062F\u0647\u0654 \u0646\u0645\u0627\u06CC\u0634\u200C\u062F\u0627\u062F\u0647\u200C\u0634\u062F\u0647 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.");
            if (q.type === "city") need2(v.trim().length > 1 && v.length <= 100, "\u0634\u0647\u0631 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.");
            clean2[q.id] = v;
          }
        }
        need2(Number.isInteger(command.step) && command.step >= 0 && command.step <= questions.length, "\u0645\u0631\u062D\u0644\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
        c.answers = clean2;
        c.step = command.step;
        c.consent = command.consent;
        c.contactConsent = command.contactConsent;
      }
      break;
    case "contact_consent":
      need2(member, "\u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u0631\u0627 \u062E\u0648\u062F \u0639\u0636\u0648 \u0645\u0634\u062E\u0635 \u0645\u06CC\u200C\u06A9\u0646\u062F.");
      c.contactConsent = command.value;
      event(command.value ? "\u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u062B\u0628\u062A \u0634\u062F" : "\u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0644\u063A\u0648 \u0634\u062F");
      break;
    case "submit":
      need2(member && c.phase === "draft" && c.consent && questions.every((q) => c.answers[q.id]), "\u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647 \u0648 \u067E\u0630\u06CC\u0631\u0634 \u0634\u0631\u0627\u06CC\u0637 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F.");
      need2(!c.urgent, "\u0628\u0631\u0627\u06CC \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631\u060C \u0627\u0628\u062A\u062F\u0627 \u0631\u0627\u0647\u0646\u0645\u0627\u06CC \u06A9\u0645\u06A9 \u0641\u0648\u0631\u06CC \u0648 \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u0631\u0627 \u062F\u0646\u0628\u0627\u0644 \u06A9\u0646\u06CC\u062F.");
      c.phase = "submitted";
      c.submittedAt = Date.now();
      event("\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0648\u0644\u06CC\u0647 \u0628\u0631\u0627\u06CC \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F");
      break;
    case "start_review":
      doctorStep();
      need2(c.phase === "submitted", "\u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u06A9\u0646\u0648\u0646 \u062F\u0631 \u0635\u0641 \u0634\u0631\u0648\u0639 \u0628\u0631\u0631\u0633\u06CC \u0646\u06CC\u0633\u062A.");
      c.phase = "reviewing";
      event("\u067E\u0632\u0634\u06A9 \u0628\u0631\u0631\u0633\u06CC \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0648\u0644\u06CC\u0647 \u0631\u0627 \u0634\u0631\u0648\u0639 \u06A9\u0631\u062F");
      break;
    case "ask":
      doctorStep();
      need2(["reviewing", "submitted"].includes(c.phase) && text(command.text), "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0631\u0648\u0634\u0646 \u0628\u0631\u0627\u06CC \u062A\u06A9\u0645\u06CC\u0644 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      c.phase = "clarification";
      c.clarification = text(command.text);
      c.clarificationReply = "";
      event("\u067E\u0632\u0634\u06A9 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u06A9\u0645\u06CC\u0644 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0641\u0631\u0633\u062A\u0627\u062F");
      break;
    case "reply":
      need2(member && c.phase === "clarification" && text(command.text), "\u067E\u0627\u0633\u062E \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u067E\u0632\u0634\u06A9 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      c.clarificationReply = text(command.text);
      c.phase = "submitted";
      event("\u067E\u0627\u0633\u062E \u062A\u06A9\u0645\u06CC\u0644\u06CC \u0628\u0631\u0627\u06CC \u067E\u0632\u0634\u06A9 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F");
      break;
    case "request_visit":
      doctorStep();
      need2(["reviewing", "submitted"].includes(c.phase) && text(command.text), "\u062F\u0644\u06CC\u0644 \u06AF\u0641\u062A\u200C\u0648\u06AF\u0648 \u0648 \u0645\u0631\u062D\u0644\u0647\u0654 \u0628\u0639\u062F \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      need2(c.contactConsent, "\u0639\u0636\u0648 \u0647\u0646\u0648\u0632 \u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0631\u0627 \u0646\u062F\u0627\u062F\u0647 \u0627\u0633\u062A.");
      c.phase = "awaiting_visit";
      c.tasks.push({ id: crypto.randomUUID(), kind: "visit", title: "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0622\u0634\u0646\u0627\u06CC\u06CC \u0628\u0627 \u067E\u0632\u0634\u06A9", why: text(command.text), owner: c.coordinator, status: "requested", date: "", time: "", place: "", mode: String(c.answers.visit || "discuss"), contactNote: "", outcome: "" });
      event("\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0645\u0644\u0627\u0642\u0627\u062A \u0628\u0647 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0631\u0633\u06CC\u062F");
      break;
    case "contact":
      {
        const t = ownTask(command.taskId);
        need2(c.contactConsent, "\u0639\u0636\u0648 \u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0631\u0627 \u0644\u063A\u0648 \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A.");
        need2(t.status === "requested" && text(command.text), "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u062A\u0645\u0627\u0633 \u0627\u0648\u0644\u06CC\u0647 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
        t.contactNote = text(command.text);
        t.status = "contacted";
        event("\u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u062A\u0645\u0627\u0633 \u0627\u0648\u0644\u06CC\u0647 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F");
      }
      break;
    case "schedule":
      {
        const t = ownTask(command.taskId);
        need2(c.contactConsent, "\u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0628\u062F\u0648\u0646 \u0627\u062C\u0627\u0632\u0647\u0654 \u062A\u0645\u0627\u0633 \u0639\u0636\u0648 \u0642\u0627\u0628\u0644 \u0627\u062F\u0627\u0645\u0647 \u0646\u06CC\u0633\u062A.");
        need2(["contacted", "proposed"].includes(t.status), "\u0627\u0628\u062A\u062F\u0627 \u062A\u0645\u0627\u0633 \u0628\u0627 \u0639\u0636\u0648 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
        need2(/^\d{4}-\d{2}-\d{2}$/.test(command.date) && !isNaN(Date.parse(command.date)) && command.date >= (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA", { timeZone: "Asia/Tehran" }), "\u062A\u0627\u0631\u06CC\u062E \u0627\u0645\u0631\u0648\u0632 \u06CC\u0627 \u0622\u06CC\u0646\u062F\u0647 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
        need2(/^([01]\d|2[0-3]):[0-5]\d$/.test(command.time) && text(command.place), "\u0632\u0645\u0627\u0646 \u0648 \u0645\u062D\u0644/\u06A9\u0627\u0646\u0627\u0644 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F.");
        need2(["online", "phone", "in_person"].includes(command.mode), "\u0646\u0648\u0639 \u0645\u0644\u0627\u0642\u0627\u062A \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
        t.date = command.date;
        t.time = command.time;
        t.place = text(command.place);
        t.mode = command.mode;
        t.status = "proposed";
        event("\u0632\u0645\u0627\u0646 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0628\u0631\u0627\u06CC \u062A\u0623\u06CC\u06CC\u062F \u0639\u0636\u0648 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F");
      }
      break;
    case "confirm":
      {
        need2(member, "\u062A\u0623\u06CC\u06CC\u062F \u0632\u0645\u0627\u0646 \u0628\u0627 \u062E\u0648\u062F \u0639\u0636\u0648 \u0627\u0633\u062A.");
        const t = task(command.taskId);
        need2(t.status === "proposed", "\u0627\u06CC\u0646 \u0632\u0645\u0627\u0646 \u062F\u06CC\u06AF\u0631 \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u062A\u0623\u06CC\u06CC\u062F \u0646\u06CC\u0633\u062A.");
        t.status = command.accept ? "confirmed" : "contacted";
        event(command.accept ? "\u0639\u0636\u0648 \u0632\u0645\u0627\u0646 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0631\u0627 \u062A\u0623\u06CC\u06CC\u062F \u06A9\u0631\u062F" : "\u0639\u0636\u0648 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0632\u0645\u0627\u0646 \u062F\u06CC\u06AF\u0631\u06CC \u062F\u0627\u062F");
      }
      break;
    case "complete_visit":
      {
        const t = ownTask(command.taskId);
        need2(t.kind === "visit" && t.status === "confirmed" && text(command.text), "\u0641\u0642\u0637 \u0645\u0644\u0627\u0642\u0627\u062A \u062A\u0623\u06CC\u06CC\u062F\u0634\u062F\u0647 \u0628\u0627 \u062B\u0628\u062A \u0646\u062A\u06CC\u062C\u0647 \u0642\u0627\u0628\u0644 \u0627\u062A\u0645\u0627\u0645 \u0627\u0633\u062A.");
        t.status = "completed";
        t.outcome = text(command.text);
        c.phase = "awaiting_plan";
        event("\u0627\u0646\u062C\u0627\u0645 \u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0646\u0645\u0648\u0646\u0647 \u062B\u0628\u062A \u0634\u062F\u061B \u0628\u0631\u0646\u0627\u0645\u0647 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0627\u0633\u062A");
      }
      break;
    case "publish":
      doctorStep();
      need2(["awaiting_plan", "active"].includes(c.phase) && text(command.summary), "\u067E\u0633 \u0627\u0632 \u062B\u0628\u062A \u0627\u0646\u062C\u0627\u0645 \u0645\u0644\u0627\u0642\u0627\u062A\u060C \u062A\u0648\u0636\u06CC\u062D \u0628\u0631\u0646\u0627\u0645\u0647 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      need2(command.actions.length > 0 && command.actions.length <= 6, "\u06CC\u06A9 \u062A\u0627 \u0634\u0634 \u0627\u0642\u062F\u0627\u0645 \u0631\u0648\u0634\u0646 \u062A\u0639\u0631\u06CC\u0641 \u06A9\u0646\u06CC\u062F.");
      {
        const plan = { id: crypto.randomUUID(), summary: text(command.summary), createdAt: Date.now(), doctor: actor.phone, actions: command.actions.map((a) => {
          need2(text(a.title) && text(a.why) && text(a.due) && ["member", "team"].includes(a.owner), "\u0639\u0646\u0648\u0627\u0646\u060C \u062F\u0644\u06CC\u0644\u060C \u0645\u0633\u0626\u0648\u0644 \u0648 \u0645\u0648\u0639\u062F \u0647\u0631 \u0627\u0642\u062F\u0627\u0645 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
          return { ...a, title: text(a.title), why: text(a.why), due: text(a.due), id: crypto.randomUUID(), done: false };
        }) };
        c.plans.push(plan);
        for (const a of plan.actions.filter((a2) => a2.owner === "team")) {
          need2(c.contactConsent, "\u0628\u0631\u0627\u06CC \u0647\u0645\u0627\u0647\u0646\u06AF\u06CC \u0627\u0642\u062F\u0627\u0645 \u062A\u06CC\u0645\u06CC\u060C \u0627\u062C\u0627\u0632\u0647\u0654 \u0639\u0636\u0648 \u0644\u0627\u0632\u0645 \u0627\u0633\u062A.");
          c.tasks.push({ id: crypto.randomUUID(), kind: "service", title: a.title, why: a.why, owner: c.coordinator, status: "requested", date: "", time: "", place: "", mode: "in_person", contactNote: "", outcome: "", planId: plan.id, actionId: a.id });
        }
        c.phase = "active";
        event("\u067E\u0632\u0634\u06A9 \u0628\u0631\u0646\u0627\u0645\u0647 \u0648 \u0642\u062F\u0645\u200C\u0647\u0627\u06CC \u0628\u0639\u062F \u0631\u0627 \u0645\u0646\u062A\u0634\u0631 \u06A9\u0631\u062F");
      }
      break;
    case "check":
      need2(member && !c.urgent, "\u062A\u06A9\u0645\u06CC\u0644 \u0627\u0642\u062F\u0627\u0645 \u0634\u062E\u0635\u06CC \u0628\u0627 \u0639\u0636\u0648 \u0627\u0633\u062A\u061B \u0647\u0634\u062F\u0627\u0631 \u0628\u0627\u0632 \u0646\u06CC\u0627\u0632 \u0628\u0647 \u0628\u0631\u0631\u0633\u06CC \u062F\u0627\u0631\u062F.");
      {
        const a = c.plans.flatMap((p) => p.actions).find((x) => x.id === command.actionId);
        need2(!c.care?.decisions[command.actionId] || c.care.decisions[command.actionId].state === "accepted", "\u0627\u0628\u062A\u062F\u0627 \u062A\u0635\u0645\u06CC\u0645 \u0631\u062F \u06CC\u0627 \u062A\u0639\u0648\u06CC\u0642 \u0627\u06CC\u0646 \u0627\u0642\u062F\u0627\u0645 \u0631\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u062F\u0647\u06CC\u062F.");
        need2(a && a.owner === "member", "\u0627\u0642\u062F\u0627\u0645 \u062A\u06CC\u0645\u06CC \u0631\u0627 \u06A9\u0627\u0631\u0634\u0646\u0627\u0633 \u0628\u0627 \u062B\u0628\u062A \u0646\u062A\u06CC\u062C\u0647 \u062A\u06A9\u0645\u06CC\u0644 \u0645\u06CC\u200C\u06A9\u0646\u062F.");
        a.done = command.done;
        event(command.done ? "\u0639\u0636\u0648 \u0627\u0646\u062C\u0627\u0645 \u0642\u062F\u0645 \u0634\u062E\u0635\u06CC \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F" : "\u0639\u0636\u0648 \u0642\u062F\u0645 \u0634\u062E\u0635\u06CC \u0631\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u0628\u0627\u0632 \u06A9\u0631\u062F");
      }
      break;
    case "upload":
      {
        const f = command.file;
        need2(member || coordinator, "\u0627\u062C\u0627\u0632\u0647\u0654 \u062B\u0628\u062A \u0645\u062F\u0631\u06A9 \u0646\u062F\u0627\u0631\u06CC\u062F.");
        need2(f.blob instanceof Blob && f.blob.size > 0 && f.blob.size <= 10 * 1024 * 1024 && ["application/pdf", "image/jpeg", "image/png"].includes(f.mime), "PDF \u06CC\u0627 \u062A\u0635\u0648\u06CC\u0631 \u0645\u0639\u062A\u0628\u0631 \u062A\u0627 \u06F1\u06F0 \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
        need2(!c.files.some((x) => x.id === f.id), "\u0627\u06CC\u0646 \u0645\u062F\u0631\u06A9 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A.");
        if (coordinator) {
          const t = ownTask(f.taskId || "");
          need2(t.kind === "service" && t.status === "confirmed", "\u06AF\u0632\u0627\u0631\u0634 \u0628\u0631\u0627\u06CC \u0627\u0642\u062F\u0627\u0645 \u062A\u0623\u06CC\u06CC\u062F\u0634\u062F\u0647 \u062B\u0628\u062A \u0645\u06CC\u200C\u0634\u0648\u062F.");
          t.status = "completed";
          t.outcome = "\u06AF\u0632\u0627\u0631\u0634 \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F\u061B \u0628\u0631\u0631\u0633\u06CC \u0628\u0627\u0644\u06CC\u0646\u06CC \u0647\u0646\u0648\u0632 \u0628\u0627 \u067E\u0632\u0634\u06A9 \u0627\u0633\u062A.";
          const action = c.plans.find((p) => p.id === t.planId)?.actions.find((a) => a.id === t.actionId);
          if (action && (!c.care?.decisions[action.id] || c.care.decisions[action.id].state === "accepted")) action.done = true;
        }
        c.files.push({ ...f, source: member ? "member" : "coordinator", createdAt: Date.now(), review: void 0, fixture: void 0 });
        event("\u0645\u062F\u0631\u06A9 \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F \u0648 \u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631 \u0628\u0631\u0631\u0633\u06CC \u067E\u0632\u0634\u06A9 \u0627\u0633\u062A");
      }
      break;
    case "review_file":
      doctorStep();
      {
        const f = c.files.find((x) => x.id === command.fileId);
        need2(f && !f.review && text(command.text), "\u06CC\u06A9 \u06AF\u0632\u0627\u0631\u0634 \u0628\u0631\u0631\u0633\u06CC\u200C\u0646\u0634\u062F\u0647 \u0648 \u062A\u0648\u0636\u06CC\u062D \u0642\u0627\u0628\u0644 \u0641\u0647\u0645 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
        f.review = { doctor: actor.phone, text: text(command.text), at: Date.now() };
        event("\u067E\u0632\u0634\u06A9 \u062A\u0648\u0636\u06CC\u062D \u06AF\u0632\u0627\u0631\u0634 \u0631\u0627 \u0645\u0646\u062A\u0634\u0631 \u06A9\u0631\u062F");
      }
      break;
    case "message":
      need2((member || doctor) && text(command.text), "\u067E\u06CC\u0627\u0645 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.");
      need2(c.phase !== "draft", "\u0627\u0628\u062A\u062F\u0627 \u0622\u0634\u0646\u0627\u06CC\u06CC \u0627\u0648\u0644\u06CC\u0647 \u0631\u0627 \u062A\u06A9\u0645\u06CC\u0644 \u06A9\u0646\u06CC\u062F.");
      c.messages.push({ id: crypto.randomUUID(), at: Date.now(), author: actor.phone, role: member ? "member" : "clinician", text: text(command.text) });
      event(member ? "\u067E\u0631\u0633\u0634 \u0639\u0636\u0648 \u0628\u0631\u0627\u06CC \u067E\u0632\u0634\u06A9 \u062B\u0628\u062A \u0634\u062F" : "\u067E\u0632\u0634\u06A9 \u067E\u0627\u0633\u062E \u0639\u0636\u0648 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F");
      break;
    case "urgent":
      need2(member && text(command.text), "\u0634\u0631\u062D \u0639\u0644\u0627\u0645\u062A \u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
      c.urgent = true;
      c.urgentReason = text(command.text);
      c.urgentNote = "";
      event("\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0631\u0633\u06CC\u062F\u06AF\u06CC \u0628\u0647 \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631 \u062B\u0628\u062A \u0634\u062F");
      break;
    case "resolve_urgent":
      need2(doctor && c.urgent && text(command.text), "\u0646\u062A\u06CC\u062C\u0647\u0654 \u0631\u0633\u06CC\u062F\u06AF\u06CC \u067E\u0632\u0634\u06A9 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0646\u06CC\u062F.");
      c.urgent = false;
      c.urgentNote = text(command.text);
      event("\u067E\u0632\u0634\u06A9 \u0646\u062A\u06CC\u062C\u0647\u0654 \u0631\u0633\u06CC\u062F\u06AF\u06CC \u0628\u0647 \u0639\u0644\u0627\u0645\u062A \u0647\u0634\u062F\u0627\u0631 \u0631\u0627 \u062B\u0628\u062A \u06A9\u0631\u062F");
      break;
    default:
      throw Error("\u0627\u0642\u062F\u0627\u0645 \u0634\u0646\u0627\u062E\u062A\u0647\u200C\u0634\u062F\u0647 \u0646\u06CC\u0633\u062A.");
  }
  syncLegacy(c, command);
  c.version++;
  return c;
}

// next/views.ts
function projectView(snapshot, user) {
  const cases = snapshot.cases, result = { user, cases: [], coordination: [], coverOffers: [] };
  if (user.role === "member") {
    const c = cases.find((c2) => c2.phone === user.phone);
    if (!c) throw Error("\u067E\u0631\u0648\u0646\u062F\u0647\u0654 \u0627\u06CC\u0646 \u062D\u0633\u0627\u0628 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    result.member = memberProjection(c);
  }
  if (user.role === "clinician") {
    result.cases = cases.filter((c) => clinicalAccess(user, c));
    result.coverOffers = cases.flatMap((c) => (c.care?.handovers || []).filter((h) => h.state === "requested" && h.to === user.phone).map((h) => ({ phone: c.phone, name: c.name, version: c.version, handoverId: h.id, from: h.from, until: h.until })));
  }
  if (user.role === "coordinator") result.coordination = cases.filter((c) => coordinationAccess(user, c)).map((c) => {
    const j = care(c), referrals = j.referrals.filter((r) => r.coordinator === user.phone).map((r) => ({ ...r, question: "" })), ids = new Set(referrals.map((r) => r.id)), reports = j.reports.filter((r) => r.referralId && ids.has(r.referralId));
    return { phone: c.phone, name: c.name, version: c.version, city: String(c.answers.city || ""), tasks: c.tasks.filter((t) => t.owner === user.phone), care: { referrals, barriers: j.barriers.filter((b) => b.owner === user.phone), reports, files: c.files.filter((f) => reports.some((r) => r.fileId === f.id)).map((f) => ({ id: f.id, name: f.name })) } };
  });
  if (user.role === "admin") result.operations = { members: cases.length, waiting: cases.filter((c) => c.urgent || ["submitted", "reviewing", "clarification"].includes(c.phase)).length, tasks: cases.reduce((n, c) => n + c.tasks.filter((t) => t.status !== "completed").length, 0), openReports: cases.reduce((n, c) => n + c.files.filter((f) => !f.review).length, 0), membersList: cases.map((c) => ({ phone: c.phone, name: c.name, doctor: c.doctor, stage: c.phase === "draft" ? "draft" : c.urgent || ["submitted", "reviewing", "clarification"].includes(c.phase) ? "review" : "care" })), work: cases.flatMap((c) => c.tasks.filter((t) => t.status !== "completed").map((t) => ({ id: t.id, member: c.name, owner: t.owner, status: t.status, kind: t.kind }))), reviewers: ["09000000011", "09000000014"].map((doctor) => ({ doctor, count: cases.filter((c) => c.doctor === doctor).reduce((n, c) => n + c.files.filter((f) => !f.review).length, 0) })), staff: ["09000000011", "09000000014", "09000000012", "09000000015"].map((phone) => ({ phone, cases: cases.filter((c) => c.doctor === phone && c.phase !== "draft").length, tasks: cases.reduce((n, c) => n + c.tasks.filter((t) => t.owner === phone && t.status !== "completed").length, 0) })), notifications: cases.flatMap((c) => (c.care?.notifications || []).map((n) => ({ phone: c.phone, version: c.version, name: c.name, id: n.id, subject: n.subject, state: n.state, attempts: n.attempts }))), memberships: cases.map((c) => ({ phone: c.phone, name: c.name, state: membershipState(c), receipts: care(c).membership.receipts.length })) };
  return result;
}
export {
  allowed,
  demoPeople,
  initialSnapshot,
  preflight,
  projectView,
  transition
};
