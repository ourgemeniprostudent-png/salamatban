سلامت‌بان نسخه ۴
از index.html شروع کن. اجرای محلی: python3 serve-demo.py
حساب‌های نمایشی و داده هر کاربر در همان مرورگر ذخیره می‌شوند. پنل پزشک و کارشناس هنوز اجرا نشده است.
راهنمای جاری documents/Salamatban-Guide-fa.html است. source/site/journey سورس فعال همین نسخه است.
